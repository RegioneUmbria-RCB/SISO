/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * The default SSO Web configuration implementation.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOWebConfigurationImpl.java,v 1.6 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class SSOWebConfigurationImpl implements SSOWebConfiguration {

    private static final Log logger = LogFactory.getLog(SSOWebConfigurationImpl.class);

    private String _loginBackToURL ;

    private String _logoutBackToURL;

    private String _sessionTokenScope;

    private boolean _sessionTokenSecure = false;

    private int _userMaxSessions;

    public String getLoginBackToURL() {
        return _loginBackToURL;
    }

    public void setLoginBackToURL(String loginBackToURL) {
        _loginBackToURL = loginBackToURL;
    }

    public String getLogoutBackToURL() {
        return _logoutBackToURL;
    }

    public void setLogoutBackToURL(String logoutBackToURL) {
        _logoutBackToURL = logoutBackToURL;
    }

    public String getSessionTokenScope() {
        return _sessionTokenScope;
    }

    public void setSessionTokenScope(String sessionTokenScope) {
        _sessionTokenScope = sessionTokenScope;
    }

    public boolean isSessionTokenSecure() {
        return _sessionTokenSecure;
    }

    public void setSessionTokenSecure(String sessionTokenSecure) {
        _sessionTokenSecure = Boolean.valueOf(sessionTokenSecure).booleanValue();
    }

    public void setSessionTokenSecure(boolean b) {
        _sessionTokenSecure = b;
    }

}
