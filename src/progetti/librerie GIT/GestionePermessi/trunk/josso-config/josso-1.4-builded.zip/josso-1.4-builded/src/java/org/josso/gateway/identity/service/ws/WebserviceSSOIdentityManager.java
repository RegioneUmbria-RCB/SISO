/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.identity.service.ws;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.gateway.identity.SSORole;
import org.josso.gateway.identity.SSOUser;
import org.josso.gateway.identity.exceptions.NoSuchUserException;
import org.josso.gateway.identity.exceptions.SSOIdentityException;
import org.josso.gateway.identity.service.BaseRoleImpl;
import org.josso.gateway.identity.service.BaseUserImpl;
import org.josso.gateway.identity.service.SSOIdentityManager;
import org.josso.gateway.identity.service.store.IdentityStore;
import org.josso.gateway.identity.service.store.IdentityStoreKeyAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Webservice client implementation for the SSO Identity Manager based on
 * the Axis-generated Stub & Skeleton.
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: WebserviceSSOIdentityManager.java,v 1.20 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class WebserviceSSOIdentityManager implements org.josso.gateway.identity.service.SSOIdentityManager {
    private static final Log logger = LogFactory.getLog(SSOIdentityManager.class);

    private org.josso.gateway.identity.service.ws.impl.SSOIdentityManager _wsSSOIdentityManager;

    private int _errorCount;

    private int _processedCount;

    /**
     * Build a Webservice SSO Identity Manager.
     *
     * @param wsSSOIdentityManager the SOAP stub to be invoked.
     */
    public WebserviceSSOIdentityManager(org.josso.gateway.identity.service.ws.impl.SSOIdentityManager wsSSOIdentityManager) {
        _wsSSOIdentityManager = wsSSOIdentityManager;
    }

    /**
     * Initializes this manager instance.
     */
    public void initialize() {

    }

    /**
     * Finds a user based on its name.  The name is a unique identifier of the user, probably the user login.
     *
     * @param name
     *
     * @throws org.josso.gateway.identity.exceptions.NoSuchUserException
     *          if the user does not exist.
     */
    public SSOUser findUser(String name)
            throws NoSuchUserException, SSOIdentityException {

        try {
            if (logger.isDebugEnabled())
                logger.debug("[findUser()] : " + name);
            return adaptSSOUser(_wsSSOIdentityManager.findUser(name));
        } catch (org.josso.gateway.identity.service.ws.impl.NoSuchUserException e) {
            throw new NoSuchUserException(e.getMessage());

        } catch (java.rmi.RemoteException e) {
            _errorCount++;
            throw new SSOIdentityException(e.getMessage(), e);
        } finally {
            _processedCount ++;
        }
    }

    /**
     * Finds the user associated to a sso session
     *
     * @param sessionId the sso session identifier
     *
     * @throws org.josso.gateway.identity.exceptions.NoSuchUserException
     *          if no user is associated to this session id.
     */
    public SSOUser findUserInSession(String sessionId)
            throws NoSuchUserException, SSOIdentityException {

        try {
            if (logger.isDebugEnabled())
                logger.debug("[findUserInSession()] : " + sessionId);
            return adaptSSOUser(_wsSSOIdentityManager.findUserInSession(sessionId));

        } catch (org.josso.gateway.identity.service.ws.impl.SSOIdentityException e) {
            throw new SSOIdentityException(e.getMessage(), e);

        } catch (java.rmi.RemoteException e) {
            logger.error(e, e);
            _errorCount ++;
            throw new SSOIdentityException(e.getMessage(), e);
        } finally {
            _processedCount ++;
        }
    }

    /**
     * Finds a collection of user's roles.
     * Elements in the collection are SSORole instances.
     *
     * @param username
     *
     * @throws org.josso.gateway.identity.exceptions.SSOIdentityException
     *
     */
    public SSORole[] findRolesByUsername(String username)
            throws SSOIdentityException {
        try {
            if (logger.isDebugEnabled())
                logger.debug("[findRolesByUsername()] : " + username);
            return adaptSSORoles(_wsSSOIdentityManager.findRolesByUsername(username));
        } catch (java.rmi.RemoteException e) {
            _errorCount ++;
            throw new SSOIdentityException(e.getMessage(), e);
        }finally {
            _processedCount ++;
        }
    }

    public void userExists(String username) throws NoSuchUserException, SSOIdentityException {
        try {
            if (logger.isDebugEnabled())
                logger.debug("[userExists()] : " + username);
            _wsSSOIdentityManager.userExists(username);
        } catch (java.rmi.RemoteException e) {
            _errorCount ++;
            throw new SSOIdentityException(e.getMessage(), e);
        } finally {
            _processedCount ++;
        }
    }


    /**
     * Maps a SOAP SSOUser type instance to a JOSSO SSOUser type instance.
     *
     * @param srcSSOUser the SOAP type instance to be mapped.
     * @return the mapped user
     */
    protected org.josso.gateway.identity.SSOUser
            adaptSSOUser(org.josso.gateway.identity.service.ws.impl.SSOUser srcSSOUser) {

        BaseUserImpl targetSSOUser = new BaseUserImpl();

        targetSSOUser.setName(srcSSOUser.getName());

        // map Properties
        org.josso.gateway.identity.service.ws.impl.SSONameValuePair[] properties =
                srcSSOUser.getProperties();

        List nvList = new ArrayList();
        for (int i = 0; i < properties.length; i++) {
            nvList.add(adaptSSOValuePair(properties[i]));
        }

        targetSSOUser.setProperties((org.josso.gateway.SSONameValuePair[])
                nvList.toArray(new org.josso.gateway.SSONameValuePair[nvList.size()]));

        return targetSSOUser;
    }

    /**
     * Maps a SOAP SSOValuePair type instance to a JOSSO SSOValuePair type instance.
     *
     * @param srcSSONameValuePair the SOAP type instance to be mapped.
     * @return the mapped value pair
     */
    protected org.josso.gateway.SSONameValuePair
            adaptSSOValuePair(org.josso.gateway.identity.service.ws.impl.SSONameValuePair srcSSONameValuePair) {

        BaseUserImpl targetSSOUser = new BaseUserImpl();
        org.josso.gateway.SSONameValuePair targetSSONameValuePair = new
                org.josso.gateway.SSONameValuePair(srcSSONameValuePair.getName(),
                        srcSSONameValuePair.getValue());

        return targetSSONameValuePair;
    }


    /**
     * Maps a SOAP SSORole type instance to a JOSSO SSORole type instance.
     *
     * @param srcSSORole the SOAP type instance to be mapped.
     * @return the mapped role
     */
    protected org.josso.gateway.identity.SSORole
            adaptSSORole(org.josso.gateway.identity.service.ws.impl.SSORole srcSSORole) {

        BaseRoleImpl targetSSORole = new BaseRoleImpl();

        targetSSORole.setName(srcSSORole.getName());
        return targetSSORole;
    }

    /**
     * Maps one or more SOAP SSORole type instancess to one or more JOSSO SSORole type instances.
     *
     * @param srcSSORoles the SOAP type instances to be mapped.
     * @return the mapped roles
     */
    protected org.josso.gateway.identity.SSORole[]
            adaptSSORoles(org.josso.gateway.identity.service.ws.impl.SSORole[] srcSSORoles) {

        ArrayList targetSSORoles = new ArrayList();
        for (int i = 0; i < srcSSORoles.length; i++) {
            targetSSORoles.add(adaptSSORole(srcSSORoles[i]));
        }

        return (SSORole[]) targetSSORoles.toArray(new BaseRoleImpl[targetSSORoles.size()]);
    }


    /**
     * Provided for compatibility only ...
     */
    public void setIdentityStoreKeyAdapter(IdentityStoreKeyAdapter a) {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    /**
     * Provided for compatibility only ...
     */
    public void setIdentityStore(IdentityStore is) {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    public int getErrorCount() {
        return _errorCount;
    }

    public int getProcessedCount() {
        return _processedCount;
    }

}
