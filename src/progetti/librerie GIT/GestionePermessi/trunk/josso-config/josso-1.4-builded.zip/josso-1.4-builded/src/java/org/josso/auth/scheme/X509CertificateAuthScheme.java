/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.auth.scheme;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.auth.Credential;
import org.josso.auth.SimplePrincipal;
import org.josso.auth.exceptions.SSOAuthenticationException;

import java.io.ByteArrayInputStream;
import java.security.Principal;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.StringTokenizer;

/**
 * Certificate-based Authentication Scheme.
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a> 
 * @version CVS $Id: X509CertificateAuthScheme.java,v 1.8 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class X509CertificateAuthScheme extends AbstractAuthenticationScheme {
    private static final Log logger = LogFactory.getLog(X509CertificateAuthScheme.class);

    /**
     * The name of the credential representing an X.509 Certificate.
     * Used to get a new credential instance based on its name and value.
     * Value : userCertificate
     *
     * @see Credential newCredential(String name, Object value)
     */
    private final static String X509_CERTIFICATE_CREDENTIAL_NAME = "userCertificate";

    /* Component Properties */
    private String _name;


    /**
     *
     *
     * @throws SSOAuthenticationException
     */
    public boolean authenticate()
            throws SSOAuthenticationException {

        setAuthenticated(false);

        //String username = getUsername(_inputCredentials);
        X509Certificate x509Certificate = getX509Certificate(_inputCredentials);

        // Check if all credentials are present.
        if (x509Certificate == null) {

            if (logger.isDebugEnabled())
                logger.debug("X.509 Certificate not provided");

            // We don't support empty values !
            return false;
        }


        //String knownUsername = getUsername(getKnownCredentials());
        X509Certificate knownX509Certificate = getX509Certificate(getKnownCredentials());

        StringBuffer buf = new StringBuffer("\n\tSupplied Credential: ");
        buf.append(x509Certificate.getSerialNumber().toString(16));
        buf.append("\n\t\t");
        buf.append(x509Certificate.getSubjectDN().getName());
        buf.append("\n\n\tExisting Credential: ");
        if( knownX509Certificate != null )
        {
           buf.append(knownX509Certificate.getSerialNumber().toString(16));
           buf.append("\n\t\t");
           buf.append(knownX509Certificate.getSubjectDN().getName());
           buf.append("\n");
        }

        logger.debug(buf.toString());

        // Validate user identity ...
        if (!validateX509Certificate(x509Certificate, knownX509Certificate)) {
            return false;
        }

        if (logger.isDebugEnabled())
            logger.debug("[authenticate()], Principal authenticated : " +
                                                        x509Certificate.getSubjectDN()
                        );

        // We have successfully authenticated this user.
        setAuthenticated(true);
        return true;
    }

    /**
     * Builds from an X509Certificate instance an X509CertificateCredentials.
     *
     * @param name the name of the credential which must be 'userCredential'.
     * @param value the value of the credential which could be:
     *              an instance of the java.security.cert.X509Certificate class,
     *              an instance of String with the encoded certificate data.
     *              an instance of byte[] with the binary certificate data.
     * @return the X509 Certificate Credential instance.
     */
    public Credential newCredential(String name, Object value)  {

        if (name.equalsIgnoreCase(X509_CERTIFICATE_CREDENTIAL_NAME)) {

            if (value instanceof X509Certificate)
                return new X509CertificateCredential(value);
            else if (value instanceof String) {
                X509Certificate cert = buildX509Certificate((String)value);
                return new X509CertificateCredential(cert);
            } else {
                X509Certificate cert = buildX509Certificate((byte[])value);
                return new X509CertificateCredential(cert);
            }
        }

        // Don't know how to handle this name ...
        if (logger.isDebugEnabled())
            logger.debug("Unknown credential name : " + name);

        return null;
    }

    private X509Certificate buildX509Certificate(byte[] binaryCert) {
    X509Certificate cert = null;

        try {
            ByteArrayInputStream bais = new ByteArrayInputStream(binaryCert);
            CertificateFactory cf =
                    CertificateFactory.getInstance("X.509");

            cert = (X509Certificate)cf.generateCertificate(bais);

            if (logger.isDebugEnabled())
                logger.debug("Building X.509 certificate result :\n " + cert);

        } catch (CertificateException ce) {
            logger.error("Error instantiating X.509 Certificate", ce);
        }

        return cert;
    }

    private X509Certificate buildX509Certificate(String plainCert) {
        return buildX509Certificate(plainCert.getBytes());
    }

    /**
     * Returns the private input credentials.
     *
     * @return the private input credentials
     */
    public Credential[] getPrivateCredentials() {
        Credential c = getX509CertificateCredential(_inputCredentials);

        if (c == null)
            return new Credential[0];

        Credential[] r = { c };
        return r;
    }

    /**
     * Returns the public input credentials.
     *
     * @return the public input credentials
     */
    public Credential[] getPublicCredentials() {
        Credential c = getX509CertificateCredential(_inputCredentials);

        if (c == null)
            return new Credential[0];

        Credential[] r = { c };
        return r;
    }

    /**
     * Instantiates a Principal for the user X509 Certificate.
     * Used as the primary key to obtain the known credentials from the associated
     * store.
     *
     * @return the Principal associated with the input credentials.
     */
    public Principal getPrincipal() {
        return getPrincipal(_inputCredentials);
    }

    /**
     * Instantiates a Principal for the user X509 Certificate.
     * Used as the primary key to obtain the known credentials from the associated
     * store.
     *
     * @return the Principal associated with the input credentials.
     */
    public Principal getPrincipal(Credential[] credentials) {
        Principal p = getX509Certificate(credentials).getSubjectDN();

        HashMap compoundName = parseCompoundName(p.getName());

        // Extract from the Distinguished Name (DN) only the Common Name (CN) since its
        // the store who sets the root naming context to be used based on the
        // store configuration.
        String cn = (String) compoundName.get("cn");

        if (cn == null)
            logger.error("Invalid Subject DN. Cannot create Principal : " +
                            p.getName()
                        );

        return new SimplePrincipal(cn);
    }


    /**
     * Gets the credential that represents an X.509 Certificate.
     *
     *
     */
    protected X509CertificateCredential getX509CertificateCredential(Credential[] credentials) {

        for (int i = 0 ; i < credentials.length ; i ++) {
            if (credentials[i] instanceof X509CertificateCredential) {
                return (X509CertificateCredential) credentials[i];
            }
        }
        return null;
    }

    /**
     * Gets the X.509 certificate from the supplied credentials
     *
     * @param credentials
     *
     */
    protected X509Certificate getX509Certificate(Credential[] credentials) {
        X509CertificateCredential c = getX509CertificateCredential(credentials);
        if (c == null)
            return null;

        return (X509Certificate) c.getValue();
    }

    /**
     * This method validates the input x509 certificate agaist the expected x509 certificate.
     *
     * @param inputX509Certificate the X.509 Certificate supplied on authentication.
     * @param expectedX509Certificate the actual X.509 Certificate
     * @return true if the certificates match or false otherwise.
     */
    protected boolean validateX509Certificate(X509Certificate inputX509Certificate,
                                              X509Certificate expectedX509Certificate) {

        if (inputX509Certificate == null && expectedX509Certificate == null)
            return false;

        return inputX509Certificate.equals(expectedX509Certificate);
    }


    /**
     * Parses a Compound name
     * (ie. CN=Java Duke, OU=Java Software Division, O=Sun Microsystems Inc, C=US) and
     * builds a HashMap object with key-value pairs.
     *
     * @param s a string containing the compound name to be parsed
     * @return a HashMap object built from the parsed key-value pairs
     * @exception IllegalArgumentException if the compound name
     *			  is invalid
     */
    private HashMap parseCompoundName(String s) {

        String valArray[] = null;

        if (s == null) {
            throw new IllegalArgumentException();
        }
        HashMap hm = new HashMap();
        StringBuffer sb = new StringBuffer();
        StringTokenizer st = new StringTokenizer(s, ",");
        while (st.hasMoreTokens()) {
            String pair = (String) st.nextToken();
            int pos = pair.indexOf('=');
            if (pos == -1) {
                // XXX
                // should give more detail about the illegal argument
                throw new IllegalArgumentException();
            }
            String key = pair.substring(0, pos).trim().toLowerCase();
            String val = pair.substring(pos + 1, pair.length()).trim();
            hm.put(key, val);
        }
        return hm;
    }

    /*------------------------------------------------------------ Properties

    /**
     * Sets Authentication Scheme name
     */
    public void setName(String name) {
        _name = name;
    }

    /**
     * Obtains the Authentication Scheme name
     */
    public String getName() {
        return _name;
    }

}
