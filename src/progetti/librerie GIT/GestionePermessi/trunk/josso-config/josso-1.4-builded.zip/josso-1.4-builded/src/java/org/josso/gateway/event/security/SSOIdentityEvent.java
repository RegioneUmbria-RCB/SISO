/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.event.security;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.Lookup;
import org.josso.auth.Credential;
import org.josso.gateway.event.BaseSSOEvent;

import java.security.Principal;

/**
 * Represents an authorizantion event, like authorization success or authorization failure.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOIdentityEvent.java,v 1.4 2006/02/15 15:43:24 sgonzalez Exp $
 */
public class SSOIdentityEvent extends BaseSSOEvent {

    private static final Log logger = LogFactory.getLog(SSOIdentityEvent.class);

    /**
     * The AuthenticationEvent event type when a user is successfully authenticated.
     */
    public static final String LOGIN_SUCCESS_EVENT = "authenticationSuccess";

    /**
     * The AuthenticationEvent event type when a user authentication fails.
     */
    public static final String LOGIN_FAILED_EVENT = "authenticationFailed";


    /**
     * The AuthenticationEvent event type when a user logout fails.
     */
    public static final String LOGOUT_FAILED_EVENT = "logoutFailed";

    /**
     * The AuthenticationEvent event type when a user logout success.
     */
    public static final String LOGOUT_SUCCESS_EVENT = "logoutSuccess";


    private String username;
    private String remoteHost;
    private String scheme;
    private String sessionId;

    /**
     * Constructs an LOGIN_SUCCESS_EVENT event
     *
     * @param username the authenticated user
     * @param sessionId the session associated with the new authenticated user.
     */
    public SSOIdentityEvent(String remoteHost, String scheme, String username, String sessionId) {
        super(LOGIN_SUCCESS_EVENT, username);
        this.sessionId = sessionId;
        this.scheme = scheme;
        this.remoteHost = remoteHost;
        this.username = username;

    }

    /**
     * Constructs an LOGIN_FAILED_EVENT event
     *
     * @param credentials that failed when attemting to authenticate a user.
     */
    public SSOIdentityEvent(String remoteHost, String scheme, Credential[] credentials, Throwable error) {
        super(LOGIN_FAILED_EVENT, credentials, error);
        this.remoteHost = remoteHost;
        this.scheme = scheme;
        // Try to guess provided username ... !
        try {
            Principal p = Lookup.getInstance().lookupSecurityDomain().getAuthenticator().getPrincipal(scheme, credentials);
            this.username = p.getName();
        } catch (Exception e) {
            logger.warn("Cannot derive principal name based on credentials ...");
        }

    }

    /**
     * Constructs an LOGOUT_SUCCESS_EVENT event
     *
     * @param username the authenticated user
     * @param sessionId the session associated with the new authenticated user.
     */
    public SSOIdentityEvent(String remoteHost, String username, String sessionId) {
        super(LOGOUT_SUCCESS_EVENT, username);
        this.sessionId = sessionId;
        this.remoteHost = remoteHost;
        this.username = username;
    }

    /**
     * Constructs an LOGOUT_SUCCESS_EVENT event
     *
     * @param username the authenticated user
     * @param sessionId the session associated with the new authenticated user.
     */
    public SSOIdentityEvent(String remoteHost, String username, String sessionId, Throwable error) {
        super(LOGOUT_FAILED_EVENT, username, error);
        this.sessionId = sessionId;
        this.remoteHost = remoteHost;
        this.username = username;
    }



    public String getUsername() {
        return username;
    }

    public String getRemoteHost() {
        return remoteHost;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String getScheme() {
        return scheme;
    }

    /**
     * Return a string representation of this event.
     */
    public String toString() {
        return ("SSOIdentityEvent['" + getType() + "']");
    }


}
