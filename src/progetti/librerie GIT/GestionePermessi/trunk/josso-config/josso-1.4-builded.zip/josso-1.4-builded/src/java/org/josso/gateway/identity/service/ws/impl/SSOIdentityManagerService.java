/**
 * SSOIdentityManagerService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jul 21, 2005 (10:26:06 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.identity.service.ws.impl;

public interface SSOIdentityManagerService extends javax.xml.rpc.Service {
    public java.lang.String getSSOIdentityManagerAddress();

    public org.josso.gateway.identity.service.ws.impl.SSOIdentityManager getSSOIdentityManager() throws javax.xml.rpc.ServiceException;

    public org.josso.gateway.identity.service.ws.impl.SSOIdentityManager getSSOIdentityManager(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
