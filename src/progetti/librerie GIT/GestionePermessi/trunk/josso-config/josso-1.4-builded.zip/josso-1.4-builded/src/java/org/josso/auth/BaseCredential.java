/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.auth;

/**
 * Base credential implementation.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: BaseCredential.java,v 1.5 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class BaseCredential implements Credential {

    protected Object _credential;

    public BaseCredential() { }

    public BaseCredential(Object credential) {
        _credential= credential;
    }

    public void setValue (Object credential) {
        _credential = credential;
    }

    public Object getValue() {
        return _credential;
    }

    /**
     * Compare this Credential value against another BaseCedential value (getValue())
     *
     * @return true if getValue() equals another.getValue()
     */
    public boolean equals(Object another)
    {
      if( !(another instanceof BaseCredential) )
        return false;

      Object anotherCredential = ((BaseCredential)another).getValue();

      boolean equals = false;
      if( _credential == null ) {
        equals = anotherCredential == null;
      } else {
        equals = _credential.equals(anotherCredential);
      }

      return equals;
    }

    /**
     * Returns the hashcode of the credential value. getValue().hashCode().
     *
     * @return the hashcode of the credential value.
     */
    public int hashCode()
    {
      return (_credential == null ? 0 : _credential.hashCode());
    }

    public String toString()
    {
      return _credential.toString();
    }


}
