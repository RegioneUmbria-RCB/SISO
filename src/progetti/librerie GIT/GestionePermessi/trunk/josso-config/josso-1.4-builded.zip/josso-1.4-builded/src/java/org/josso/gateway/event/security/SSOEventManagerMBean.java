/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.event.security;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.gateway.event.SSOEventListener;
import org.josso.util.mbeans.JOSSOBaseMBean;

import javax.management.*;

/**
 * TODO : Add class description.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOEventManagerMBean.java,v 1.5 2006/02/15 15:43:24 sgonzalez Exp $
 */
/**
 * This class is
 */
public class SSOEventManagerMBean extends JOSSOBaseMBean {

    private static final Log logger = LogFactory.getLog(SSOEventManagerMBean.class);


    public SSOEventManagerMBean() throws MBeanException, RuntimeOperationsException {
        super();
    }

    public void addNotificationListener(SSOEventListener listener) throws InstanceNotFoundException {

        MBeanServer server = this.registry.getMBeanServer();

        // Wrapp received listener with JMX listener.
        // This hardly works ... because in different versions of common-modeler, oname is a String or a ObjectName instance !!!
        server.addNotificationListener(oname, new NotificationSSOEventListener(listener), null, null);
    }

    public String getOName() {
        // This hardly works ... because in different versions of common-modeler, oname is a String or a ObjectName instance !!!
        return oname + "";
    }

    /**
     * This method will be invoked by the outer class when sending SSO Events.
     * @param event
     */
    public void fireJMXSSOEvent(Notification event) {
        try {
            
            sendNotification(event);

            if (logger.isDebugEnabled())
                logger.debug("Sent notification : " + event);
        } catch (MBeanException e) {
            logger.error("Can't send JMX Notification : " + e.getMessage(), e);
        }
    }

}


