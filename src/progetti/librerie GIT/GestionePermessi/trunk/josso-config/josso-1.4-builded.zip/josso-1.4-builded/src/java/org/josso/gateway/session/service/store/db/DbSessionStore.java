/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */

package org.josso.gateway.session.service.store.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.gateway.session.exceptions.SSOSessionException;
import org.josso.gateway.session.service.BaseSession;
import org.josso.gateway.session.service.MutableBaseSession;
import org.josso.gateway.session.service.store.SessionStore;
import org.josso.gateway.session.service.store.AbstractSessionStore;

/**
 * An abstraction of a SessionStore backed by a database.
 *
 * <p>
 * Additional component properties include:
 * <ul>
 * <li>sizeQuery = The SQL Query used to add a new session to the store.</li>
 * <li>keysQuery = The SQL Query used to retrieve all session ids. The first column for each row in the result set must be the session id.</li>
 * <li>loadAllQuery = The SQL Query used to load all sessions from the store.</li>
 * <li>loadQuery = The SQL Query used to load one session from the store based on its id.</li>
 * <li>loadByUserNameQuery = The SQL Query used to load all sessions associated to a given user.</li>
 * <li>loadByLastAccesstimeQuery = The SQL Query used to load all sessions last accessed before the given date.</li>
 * <li>loadByValidQuery = The SQL Query used to load all sessions whose valid property is equals to the gvien argument.</li>
 * <li>deleteDml = The SQL Query used to remove a session from the store.</li>
 * <li>deletAllDml = The SQL Query used to remove ALL sessions from the store.</li>
 * <li>insertDml = The SQL Query used to add a new session to the store.</li>
 * </ul>
 * </p>
 * <p>
 * The columns in the result set for all load methods must be in the following order :
 * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
 * </p>
 * <p>
 * lastAccessTime and creationTime are treated as a longs, not dates.
 * </p>
 *
 * @author Jeff Gutierrez (code@gutierrez.ph) ca
 *
 */
public abstract class DbSessionStore extends AbstractSessionStore {
    private static final Log __log = LogFactory.getLog( DbSessionStore.class );

    private String _sizeQuery = null;
    private String _keysQuery = null;
    private String _loadAllQuery = null;
    private String _loadQuery = null;
    private String _loadByUserNameQuery = null;
    private String _loadByLastAccessTimeQuery = null;
    private String _loadByValidQuery = null;

    private String _deleteDml = null;
    private String _deleteAllDml = null;
    private String _insertDml = null;


    // -------------------------------------
    // DbSessinStore-specific
    // -------------------------------------

    /**
     * Implementation classes implement this method.
     *
     * @return A database connection.
     */
    protected abstract Connection getConnection() throws SQLException, SSOSessionException;


    /**
     * Close the given db connection.
     *
     * @param dbConnection
     */
    protected void close( Connection dbConnection ) throws SSOSessionException
    {
        try
        {
            if( dbConnection != null
                && !dbConnection.isClosed() )
            {
                dbConnection.close();
            }
        }
        catch( SQLException se )
        {
            if( __log.isDebugEnabled() )
                __log.debug( "Error while clossing connection");

            throw new SSOSessionException( "Error while clossing connection\n" + se.getMessage() );
        }
        catch (Exception e)
        {
            if( __log.isDebugEnabled() )
                __log.debug( "Error while clossing connection" );

            throw new SSOSessionException("Error while clossing connection\n" + e.getMessage());
        }

    }


    // -------------------------------------------------
    // Configuration properties
    // -------------------------------------------------

    /**
     * The SQL Query used to add a new session to the store.
     *
     * @param query
     */
    public void setInsertDml( String query )
    {
        _insertDml = query;
    }
    public String getInsertDml()
    {
        return _insertDml ;
    }

    /**
     * The SQL Query used to remove ALL sessions from the store.
     *
     */
    public void setDeleteAllDml( String query )
    {
        _deleteAllDml = query;
    }
    public String getDeleteAllDml()
    {
        return _deleteAllDml;
    }


    /**
     * The SQL Query used to remove a session from the store.
     *
     */
    public void setDeleteDml( String query )
    {
        _deleteDml = query;
    }
    public String getDeleteDml()
    {
        return _deleteDml;
    }


    /**
     * The SQL Query used to load all sessions last accessed before the given date.
     *
     * The columns in the result set must be in the following order :
     * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     */
    public void setLoadByLastAccessTimeQuery( String query )
    {
        _loadByLastAccessTimeQuery = query;
    }
    public String getLoadByLastAccessTimeQuery()
    {
        return _loadByLastAccessTimeQuery;
    }

    /**
     * The SQL Query used to load all sessions whose valid property is equals to the given valid.
     *
     * The columns in the result set must be in the following order :
     * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     */
    public void setLoadByValidQuery( String query )
    {
        _loadByValidQuery = query;
    }
    public String getLoadByValidQuery()
    {
        return _loadByValidQuery;
    }

    /**
     * The SQL Query used to load all sessions associated to a given user.
     *
     * The columns in the result set must be in the following order :
     * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     *
     * @param query
     */
    public void setLoadByUserNameQuery( String query )
    {
        _loadByUserNameQuery = query;
    }
    public String getLoadByUserNameQuery()
    {
        return _loadByUserNameQuery;
    }



    /**
     * The SQL query used to retrieve the number of sessions in the store.
     * The first column of the first row in the result set must be the number of sessions.
     */
    public void setSizeQuery( String query )
    {
        _sizeQuery = query;
    }
    public String getSizeQuery()
    {
        return _sizeQuery;
    }

    /**
     * The SQL Query used to retrieve all session ids.
     * The first column for each row in the result set must be the session id.
     */
    public void setKeysQuery( String query )
    {
        _keysQuery = query;
    }
    public String getKeysQuery()
    {
        return _keysQuery;
    }


    /**
     * The SQL Query used to load all sessions from the store.
     *
     * The columns in the result set must be in the following order :
     * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     *
     * @param query
     */
    public void setLoadAllQuery( String query )
    {
        _loadAllQuery = query;
    }
    public String getLoadAllQuery()
    {
        return _loadAllQuery;
    }

    /**
     * The SQL Query used to load one session from the store based on its id.
     *
     * The columns in the result set must be in the following order :
     * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     *
     * example : SELECT sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid FROM JOSSO_SESSION WHERE sessionId = ?
     *
     * @param query
     */
    public void setLoadQuery( String query )
    {
        _loadQuery = query;
    }
    public String getLoadQuery()
    {
        return _loadQuery;
    }


    // --------------------------------
    // SessionStore implementation
    // --------------------------------


    /**
     * This method returns the number of stored sessions.
     *
     * The first column of the first row in the result set must be the number of sessions.
     *
     * @see #setSizeQuery(String)
     *
     * @return the number of sessions
     * @exception SSOSessionException
     */
    public int getSize() throws SSOSessionException
    {
        int retval = 0;

        Connection conn = null;

        // - Submit query
        // - First column of the first row is the number of sessions.
        //

        try
        {
            conn = getConnection();
            final ResultSet rs = conn.createStatement().executeQuery( _sizeQuery );
            if( rs != null && rs.next() ) {
                retval = rs.getInt( 1 );
            }

            rs.close();
        }
        catch( Exception e )
        {
            if( __log.isDebugEnabled() )
                __log.debug( e , e);
            throw new SSOSessionException( e );
        }
        finally
        {
            close( conn );
        }

        if( __log.isDebugEnabled() )
            __log.debug( "Returning " + retval );

        return retval;
    }


    /**
     * Returns all session keys (ids)
     *
     * The first column for each row in the result set must be the session id.
     *
     * @see #setKeysQuery(String)
     *
     * @return The session keys
     * @exception SSOSessionException
     */
    public String[] keys() throws SSOSessionException
    {
        String[] retval = null;

        Connection conn = null;

        // - Submit query
        // - First column for each row is the session id.
        //

        try
        {
            conn = getConnection();
            final ResultSet rs = conn.createStatement().executeQuery( _keysQuery );
            final ArrayList bucket = new ArrayList();

            while( rs.next() )
                bucket.add( rs.getString( 1 ) );

            rs.close();

            retval = new String[ bucket.size() ];
            bucket.toArray( retval );
        }
        catch( Exception e )
        {
            if( __log.isDebugEnabled() )
                __log.debug( e , e);
            throw new SSOSessionException( e );
        }
        finally
        {
            close( conn );
        }

        return retval;
    }


    /**
     * Loads all stored sessions.
     *
     * The columns in the result set must be in the following order :
     * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     *
     * @see #setLoadAllQuery(String)
     */
    public BaseSession[] loadAll() throws SSOSessionException
    {
        BaseSession[] retval = null;

        Connection conn = null;

        // - Submit query
        // - Expected columns, in order:
        // sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
        //

        try
        {
            conn = getConnection();
            final ResultSet rs = conn.createStatement().executeQuery( _loadAllQuery );
            retval = getSessions( rs );
            rs.close();
        }
        catch( Exception e )
        {
            if( __log.isDebugEnabled() )
                __log.debug( e , e);
            throw new SSOSessionException( e );
        }
        finally
        {
            close( conn );
        }

        return retval;
    }


    /**
     * Loads a session based on its id.
     *
     * The columns in the result set must be in the following order :
     * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     *
     * @see #setLoadQuery(String)
     *
     * @param id
     * @return
     * @throws SSOSessionException
     */
    public BaseSession load( String id ) throws SSOSessionException
    {
        BaseSession retval = null;
        Connection conn = null;

        try
        {
            conn = getConnection();
            final PreparedStatement ps = conn.prepareStatement( _loadQuery );
            ps.setString( 1, id );

            final ResultSet rs = ps.executeQuery();
            if( rs.next() )
                retval = createFromResultSet( rs );

            rs.close();

        }
        catch( Exception e )
        {
            if( __log.isDebugEnabled() )
                __log.debug( e , e);
            throw new SSOSessionException( e );
        }
        finally
        {
            close( conn );
        }

        id = ( retval == null )
            ? "NOT FOUND"
            : retval.getId();

        if( __log.isDebugEnabled() )
            __log.debug( "Loaded session: " + id );

        return retval;
    }


    /**
     * Loads all sessions based on the associated username
     *
     * The columns in the result set must be in the following order :
     * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     *
     * @see #setLoadByUserNameQuery(String)
     */
    public BaseSession[] loadByUsername( String userName ) throws SSOSessionException
    {
        BaseSession[] retval = null;
        Connection conn = null;

        try
        {
            conn = getConnection();
            final PreparedStatement ps = conn.prepareStatement( _loadByUserNameQuery );
            ps.setString( 1, userName );

            final ResultSet rs = ps.executeQuery();
            retval = getSessions( rs );
            rs.close();
        }
        catch( Exception e )
        {
            if( __log.isDebugEnabled() )
                __log.debug( e , e);
            throw new SSOSessionException( e );
        }
        finally
        {
            close( conn );
        }

        return retval;
    }


    /**
     * Loads all sessions last accessed before the given date.
     *
     * The date is converted to java.sql.Date when setting up the prepared statement.
     *
     * The columns in the result set must be in the following order :
     * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     *
     * @see #setLoadByLastAccessTimeQuery(String)
     */
    public BaseSession[] loadByLastAccessTime( Date date )
            throws SSOSessionException
    {
        BaseSession[] retval = null;
        Connection conn = null;

        try
        {
            conn = getConnection();
            final PreparedStatement ps = conn.prepareStatement( _loadByLastAccessTimeQuery );
            ps.setLong( 1, date.getTime() );

            final ResultSet rs = ps.executeQuery();
            retval = getSessions( rs );

            rs.close();
        }
        catch( Exception e )
        {
            if( __log.isDebugEnabled() )
                __log.debug( e , e);
            throw new SSOSessionException( e );
        }
        finally
        {
            close( conn );
        }

        return retval;
    }

    /**
     * Loads all sessions whose valid property is equals to the received argument.
     *
     * @see #setLoadByValidQuery(String)
     */
    public BaseSession[] loadByValid( boolean valid)
            throws SSOSessionException
    {
        BaseSession[] retval = null;
        Connection conn = null;

        try
        {
            conn = getConnection();
            final PreparedStatement ps = conn.prepareStatement( _loadByValidQuery );
            ps.setBoolean( 1, valid);

            final ResultSet rs = ps.executeQuery();
            retval = getSessions( rs );

            rs.close();
        }
        catch( Exception e )
        {
            if( __log.isDebugEnabled() )
                __log.debug( e , e);
            throw new SSOSessionException( e );
        }
        finally
        {
            close( conn );
        }

        return retval;
    }


    /**
     * Removes a session from the store based on its id
     *
     * @see #setDeleteDml(String)
     *
     * @exception SSOSessionException
     */
    public void remove( String id ) throws SSOSessionException
    {
        Connection conn = null;

        try
        {
            conn = getConnection();
            delete( conn, id );
            conn.commit();
        }
        catch( Exception e )
        {
            if( __log.isDebugEnabled() )
                __log.debug( e , e);
            throw new SSOSessionException( e );
        }
        finally
        {
            close( conn );
        }
    }


    /**
     * Removes ALL stored sessions
     *
     * @see #setDeleteAllDml(String)
     *
     * @throws SSOSessionException
     */
    public void clear() throws SSOSessionException
    {
        Connection conn = null;

        try
        {
            conn = getConnection();
            final Statement stmt = conn.createStatement();
            stmt.execute( _deleteAllDml );
            conn.commit();

            stmt.close();
        }
        catch( Exception e )
        {
            if( __log.isDebugEnabled() )
                __log.debug( e , e);

            throw new SSOSessionException( e );
        }
        finally
        {
            close( conn );
        }
    }

    /**
     * Stores a session in the DB.  This method opens a transaccion, removes the old session if present, the creates
     * it again using the configured savenDml Query and commits the transaction.
     *
     * Session attributes will be passed to the prepared statemetn in the following order :
     * sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     *
     * @see #setInsertDml(String)
     *
     * @param session
     * @throws SSOSessionException
     */
    public void save( BaseSession session ) throws SSOSessionException
    {
        Connection conn = null;

        // - Expected columns, in order:
        // sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid

        try
        {
            conn = getConnection();
            delete( conn, session.getId() );
            insert( conn, session);
            conn.commit();
            if( __log.isDebugEnabled() )
                __log.debug( "Session committed: " + session.getId() );
        }
        catch( Exception e )
        {
            if( __log.isDebugEnabled() )
                __log.debug( e , e);

            if (conn != null) {

                try {
                    conn.rollback();
                } catch (SQLException sqle) {
                    if (__log.isDebugEnabled())
                        __log.debug("Error during ROLLBACK ", sqle);
                }
            }

            throw new SSOSessionException( e );
        }
        finally
        {
            close( conn );
        }

        if( __log.isDebugEnabled() )
            __log.debug( "Saved session: " + session.getId() );
    }


    // ---------------------------
    // Private Methods
    // ---------------------------

    /**
     * This removes a session, using the value of the removeDml property as prepared statement.
     *
     * @param conn
     * @param sessionId
     * @throws SQLException
     */
    protected void delete( Connection conn, String sessionId ) throws SQLException
    {
        final PreparedStatement ps = conn.prepareStatement( _deleteDml );
        ps.setString( 1, sessionId );
        ps.execute();

        if( __log.isDebugEnabled() )
            __log.debug( "Session Removed: " + sessionId );
    }

    protected void insert( Connection conn, BaseSession session ) throws SQLException
    {
        final PreparedStatement ps = conn.prepareStatement( _insertDml  );
        ps.setString( 1, session.getId() );
        ps.setString( 2, session.getUsername() );
        ps.setLong( 3, session.getCreationTime() );
        ps.setLong( 4, session.getLastAccessTime() );
        ps.setInt( 5, (int) session.getAccessCount() );
        ps.setInt( 6, session.getMaxInactiveInterval() );
        ps.setBoolean( 7, session.isValid() );
        ps.execute();

        if( __log.isDebugEnabled() )
            __log.debug( "Creation, LastAccess: " + session.getCreationTime() + ", " + session.getCreationTime() );

        if( __log.isDebugEnabled() )
        __log.debug( "Session inserted: " + session.getId() );
    }


    /**
     *
     */
    protected BaseSession[] getSessions( ResultSet rs ) throws SQLException
    {
        final ArrayList bucket = new ArrayList();

        // - Collect the sessions
        // - Return the sessions in an array.
        //

        while( rs.next() )
            bucket.add( createFromResultSet( rs ) );

        final BaseSession[] retval = new BaseSession[ bucket.size() ];
        bucket.toArray( retval );

        return retval;
    }

    /**
     * This method builds a session instance based on a result set.
     *
     * Expected columns, in order:
     *   sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid
     *
     * @param rs
     * @return
     * @throws SQLException
     */
    protected BaseSession createFromResultSet( ResultSet rs ) throws SQLException
    {
        // - Expected columns, in order:
        // sessionId, userName, creationTime, lastAccessTime, accessCount, maxInactiveInterval, valid

        final MutableBaseSession bsi = new MutableBaseSession();
        bsi.setId( rs.getString( 1 ) );
        bsi.setUsername( rs.getString( 2 ) );
        bsi.setCreationTime( rs.getLong( 3 ) );
        bsi.setLastAccessedTime( rs.getLong( 4 ) );
        bsi.setAccessCount( rs.getLong( 5 ) );
        bsi.setMaxInactiveInterval( rs.getInt( 6 ) );
        bsi.setValid( rs.getBoolean( 7 ) );

        return bsi;
    }
}
