/**
 * SSOEventManagerClientSoapBindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jul 21, 2005 (10:26:06 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.event.client.ws.impl;

public class SSOEventManagerClientSoapBindingSkeleton implements org.josso.gateway.event.client.ws.impl.SSOEventManagerClient, org.apache.axis.wsdl.Skeleton {
    private org.josso.gateway.event.client.ws.impl.SSOEventManagerClient impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in3"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "anyType"), java.lang.Object.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("fireSessionEvent", _params, null);
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/event/client/ws/impl", "fireSessionEvent"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("fireSessionEvent") == null) {
            _myOperations.put("fireSessionEvent", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("fireSessionEvent")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOEventException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/event/client/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.event.client.ws.impl.SSOEventException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/event/client/ws/impl", "SSOEventException"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://josso.org/gateway/event/client/ws/impl", "SSOEvent"), org.josso.gateway.event.client.ws.impl.SSOEvent.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("fireSSOEvent", _params, null);
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/event/client/ws/impl", "fireSSOEvent"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("fireSSOEvent") == null) {
            _myOperations.put("fireSSOEvent", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("fireSSOEvent")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOEventException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/event/client/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.event.client.ws.impl.SSOEventException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/event/client/ws/impl", "SSOEventException"));
        _oper.addFault(_fault);
    }

    public SSOEventManagerClientSoapBindingSkeleton() {
        this.impl = new org.josso.gateway.event.client.ws.impl.SSOEventManagerClientSoapBindingImpl();
    }

    public SSOEventManagerClientSoapBindingSkeleton(org.josso.gateway.event.client.ws.impl.SSOEventManagerClient impl) {
        this.impl = impl;
    }
    public void fireSessionEvent(java.lang.String in0, java.lang.String in1, java.lang.String in2, java.lang.Object in3) throws java.rmi.RemoteException, org.josso.gateway.event.client.ws.impl.SSOEventException
    {
        impl.fireSessionEvent(in0, in1, in2, in3);
    }

    public void fireSSOEvent(org.josso.gateway.event.client.ws.impl.SSOEvent in0) throws java.rmi.RemoteException, org.josso.gateway.event.client.ws.impl.SSOEventException
    {
        impl.fireSSOEvent(in0);
    }

}
