/**
 * SSOIdentityManagerSoapBindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jul 21, 2005 (10:26:06 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.identity.service.ws.impl;

public class SSOIdentityManagerSoapBindingSkeleton implements org.josso.gateway.identity.service.ws.impl.SSOIdentityManager, org.apache.axis.wsdl.Skeleton {
    private org.josso.gateway.identity.service.ws.impl.SSOIdentityManager impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
        };
        _oper = new org.apache.axis.description.OperationDesc("initialize", _params, null);
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "initialize"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("initialize") == null) {
            _myOperations.put("initialize", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("initialize")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findUser", _params, new javax.xml.namespace.QName("", "findUserReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "SSOUser"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "findUser"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findUser") == null) {
            _myOperations.put("findUser", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findUser")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOIdentityException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.identity.service.ws.impl.SSOIdentityException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "SSOIdentityException"));
        _oper.addFault(_fault);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("NoSuchUserException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.identity.service.ws.impl.NoSuchUserException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "NoSuchUserException"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findUserInSession", _params, new javax.xml.namespace.QName("", "findUserInSessionReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "SSOUser"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "findUserInSession"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findUserInSession") == null) {
            _myOperations.put("findUserInSession", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findUserInSession")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOIdentityException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.identity.service.ws.impl.SSOIdentityException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "SSOIdentityException"));
        _oper.addFault(_fault);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("NoSuchUserException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.identity.service.ws.impl.NoSuchUserException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "NoSuchUserException"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("findRolesByUsername", _params, new javax.xml.namespace.QName("", "findRolesByUsernameReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "ArrayOfSSORole"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "findRolesByUsername"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("findRolesByUsername") == null) {
            _myOperations.put("findRolesByUsername", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("findRolesByUsername")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOIdentityException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.identity.service.ws.impl.SSOIdentityException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "SSOIdentityException"));
        _oper.addFault(_fault);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "in0"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("userExists", _params, null);
        _oper.setElementQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "userExists"));
        _oper.setSoapAction("");
        _myOperationsList.add(_oper);
        if (_myOperations.get("userExists") == null) {
            _myOperations.put("userExists", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("userExists")).add(_oper);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("SSOIdentityException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.identity.service.ws.impl.SSOIdentityException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "SSOIdentityException"));
        _oper.addFault(_fault);
        _fault = new org.apache.axis.description.FaultDesc();
        _fault.setName("NoSuchUserException");
        _fault.setQName(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "fault"));
        _fault.setClassName("org.josso.gateway.identity.service.ws.impl.NoSuchUserException");
        _fault.setXmlType(new javax.xml.namespace.QName("http://josso.org/gateway/identity/service/ws/impl", "NoSuchUserException"));
        _oper.addFault(_fault);
    }

    public SSOIdentityManagerSoapBindingSkeleton() {
        this.impl = new org.josso.gateway.identity.service.ws.impl.SSOIdentityManagerSoapBindingImpl();
    }

    public SSOIdentityManagerSoapBindingSkeleton(org.josso.gateway.identity.service.ws.impl.SSOIdentityManager impl) {
        this.impl = impl;
    }
    public void initialize() throws java.rmi.RemoteException
    {
        impl.initialize();
    }

    public org.josso.gateway.identity.service.ws.impl.SSOUser findUser(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException, org.josso.gateway.identity.service.ws.impl.NoSuchUserException
    {
        org.josso.gateway.identity.service.ws.impl.SSOUser ret = impl.findUser(in0);
        return ret;
    }

    public org.josso.gateway.identity.service.ws.impl.SSOUser findUserInSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException, org.josso.gateway.identity.service.ws.impl.NoSuchUserException
    {
        org.josso.gateway.identity.service.ws.impl.SSOUser ret = impl.findUserInSession(in0);
        return ret;
    }

    public org.josso.gateway.identity.service.ws.impl.SSORole[] findRolesByUsername(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException
    {
        org.josso.gateway.identity.service.ws.impl.SSORole[] ret = impl.findRolesByUsername(in0);
        return ret;
    }

    public void userExists(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException, org.josso.gateway.identity.service.ws.impl.NoSuchUserException
    {
        impl.userExists(in0);
    }

}
