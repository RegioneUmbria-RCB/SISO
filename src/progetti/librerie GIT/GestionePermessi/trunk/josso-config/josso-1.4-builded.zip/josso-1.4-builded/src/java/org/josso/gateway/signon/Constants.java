/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.signon;

/**
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: Constants.java,v 1.3 2006/02/09 16:53:06 sgonzalez Exp $
 */

public interface Constants extends org.josso.gateway.Constants {

    /**
     * Reqeuest parameter representing an SSO command.
     * Value : sso_cmd
     */
    public static final String PARAM_JOSSO_CMD="josso_cmd";

    /**
     * Request parameter to set the back-to url used after a successfull login.
     */
    public static final String PARAM_JOSSO_BACK_TO="josso_back_to";

    /**
     * Request parameter to set the on-error to url used after an invalid login.
     */
    public static final String PARAM_JOSSO_ON_ERROR="josso_on_error";

    /**
     * Key to store a String representing the URL were the user should be redirected to after a successfull login.
     */
    public static final String KEY_JOSSO_BACK_TO="org.josso.gateway.backToUrl";


    /**
     * Key to store a String representing the URL were the user should be redirected to after an invalid login attempt
     */
    public static final String KEY_JOSSO_ON_ERROR="org.josso.gateway.onErrorUrl";

    /**
     * Key used to store the SSOGateway instance in the application context.
     * Value : org.josso.gateway
     */
    public static final String KEY_JOSSO_GATEWAY="org.josso.gateway";

    /**
     * Key to store a SSOUser instance in any scope.
     */
    public static final String KEY_JOSSO_USER="org.josso.gateway.user";

    /**
     * Key to store a SSORole[] instance in any scope.
     */
    public static final String KEY_JOSSO_USER_ROLES="org.josso.gateway.userRoles";
    /**
     * Key to store a SSOUser instance in any scope.
     */
    public static final String KEY_JOSSO_SESSION="org.josso.gateway.session";

}
