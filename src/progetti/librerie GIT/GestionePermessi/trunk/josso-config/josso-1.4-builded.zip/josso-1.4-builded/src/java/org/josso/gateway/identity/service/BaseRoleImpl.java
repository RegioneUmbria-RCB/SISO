/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.identity.service;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.security.Principal;
import java.util.*;

/**
 * An implementation of BaseRole that manages a collection of Principal
 * objects based on their hashCode() and equals() methods.
 * This class is not thread safe.
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: BaseRoleImpl.java,v 1.8 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class BaseRoleImpl implements BaseRole {
    private static final Log logger = LogFactory.getLog(BaseRoleImpl.class);


    private String _name;
    private HashMap members;

    public BaseRoleImpl(String name) {
        this();
        _name = name;
    }

    public BaseRoleImpl() {
        members = new HashMap(3);
    }

    /**
     * Adds the specified member to the group.
     *
     * @param user the principal to add to this group.
     * @return true if the member was successfully added,
     *         false if the principal was already a member.
     */
    public boolean addMember(Principal user) {
        boolean isMember = members.containsKey(user);
        if (isMember == false)
            members.put(user, user);
        return isMember == false;
    }

    /**
     * Returns true if the passed principal is a member of the group.
     * This method does a recursive search, so if a principal belongs to a
     * group which is a member of this group, true is returned.
     * <p/>
     * A special check is made to see if the member is an instance of
     * org.jboss.security.AnybodyPrincipal or org.jboss.security.NobodyPrincipal
     * since these classes do not hash to meaningful values.
     *
     * @param member the principal whose membership is to be checked.
     * @return true if the principal is a member of this group,
     *         false otherwise.
     */
    public boolean isMember(Principal member) {
        // logger.debug("Begin, isMember");

        // First see if there is a key with the member name
        boolean isMember = members.containsKey(member);
        if (isMember == false) {   // Check any Groups for membership
            Collection values = members.values();
            Iterator iter = values.iterator();
            while (isMember == false && iter.hasNext()) {
                Object next = iter.next();
                if (next instanceof BaseRole) {
                    BaseRole role = (BaseRole) next;
                    isMember = role.isMember(member);
                }
            }
        }

        // logger.debug("End, isMember, return=" + isMember);
        return isMember;
    }

    /**
     * Returns an enumeration of the members in the group.
     * The returned objects can be instances of either Principal
     * or Group (which is a subinterface of Principal).
     *
     * @return an enumeration of the group members.
     */
    public Enumeration members() {
        return Collections.enumeration(members.values());
    }

    /**
     * Removes the specified member from the group.
     *
     * @param user the principal to remove from this group.
     * @return true if the principal was removed, or
     *         false if the principal was not a member.
     */
    public boolean removeMember(Principal user) {
        Object prev = members.remove(user);
        return prev != null;
    }

    public String getName() {
        return _name;
    }

    public void setName(String name) {
        _name = name;
    }

    public String toString() {
        StringBuffer tmp = new StringBuffer(getName());
        tmp.append("(members:");
        Iterator iter = members.keySet().iterator();
        while (iter.hasNext()) {
            tmp.append(iter.next());
            tmp.append(',');
        }
        tmp.setCharAt(tmp.length() - 1, ')');
        return tmp.toString();
    }

    /**
     * Compare this BaseRole's name against another BaseRole
     *
     * @return true if name equals another.getName();
     */
    public boolean equals(Object another) {
        if (!(another instanceof BaseRole))
            return false;
        String anotherName = ((BaseRole) another).getName();
        boolean equals = false;
        if (_name == null)
            equals = anotherName == null;
        else
            equals = _name.equals(anotherName);
        return equals;
    }

    public int hashCode() {
        return (_name == null ? 0 : _name.hashCode());
    }

}
