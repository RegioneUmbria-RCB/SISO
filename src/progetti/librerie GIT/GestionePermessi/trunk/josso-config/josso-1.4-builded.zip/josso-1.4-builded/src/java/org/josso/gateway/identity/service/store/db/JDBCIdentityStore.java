/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.identity.service.store.db;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.gateway.identity.exceptions.SSOIdentityException;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.SQLException;
import java.util.Properties;

/**
 * JDBC Implementation of a DB Identity and Credential Store.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: JDBCIdentityStore.java,v 1.10 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class JDBCIdentityStore extends AbstractDBIdentityStore {

    private static final Log logger = LogFactory.getLog(JDBCIdentityStore.class);

    /**
     * The connection username to use when trying to connect to the database.
     */
    protected String _connectionName = null;

    /**
     * The connection URL to use when trying to connect to the database.
     */
    protected String _connectionPassword = null;


    /**
     * The connection URL to use when trying to connect to the database.
     */
    protected String _connectionURL = null;

    /**
     * Instance of the JDBC Driver class we use as a connection factory.
     */
    protected Driver _driver = null;

    /**
     * The JDBC driver to use.
     */
    protected String _driverName = null;

    /**
     * TODO : Use a connection pool to improve performance.
     * 
     *
     * @throws SSOIdentityException
     */
    protected Connection getDBConnection() throws SSOIdentityException {

        // Instantiate our database driver if necessary
        if (_driver == null) {
            try {
                Class clazz = Class.forName(_driverName);
                _driver = (Driver) clazz.newInstance();
            } catch (Throwable e) {
                throw new SSOIdentityException(e.getMessage(), e);
            }
        }

        // Open a new connection
        Properties props = new Properties();
        if (_connectionName != null)
            props.put("user", _connectionName);

        if (_connectionPassword != null)
            props.put("password", _connectionPassword);

        try {
            Connection c = _driver.connect(_connectionURL, props);
            c.setAutoCommit(false);
            return (c);

        } catch (SQLException e) {
            logger.error("[getDBConnection()]:" + e.getErrorCode() + "/" + e.getSQLState() + "]" + e.getMessage());
            throw new SSOIdentityException(e.getMessage(), e);
        }

    }

    public String getConnectionName() {
        return _connectionName;
    }

    public void setConnectionName(String connectionName) {
        _connectionName = connectionName;
    }

    public String getConnectionPassword() {
        return _connectionPassword;
    }

    public void setConnectionPassword(String connectionPassword) {
        _connectionPassword = connectionPassword;
    }

    public String getConnectionURL() {
        return _connectionURL;
    }

    public void setConnectionURL(String connectionURL) {
        _connectionURL = connectionURL;
    }

    public String getDriverName() {
        return _driverName;
    }

    public void setDriverName(String driverName) {
        _driverName = driverName;
    }

}
