/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.session.service;

import org.josso.gateway.session.SSOSession;
import org.josso.gateway.session.exceptions.NoSuchSessionException;
import org.josso.gateway.session.exceptions.SSOSessionException;
import org.josso.gateway.session.exceptions.TooManyOpenSessionsException;
import org.josso.gateway.session.service.store.SessionStore;

import java.util.Collection;

/**
 * SSO Session Manager Business interface.
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: SSOSessionManager.java,v 1.17 2006/02/09 16:53:06 sgonzalez Exp $
 */
public interface SSOSessionManager extends java.io.Serializable {

    /**
     * Initiates a new session. The session id is returned.
     *
     * @return the new session identifier.
     * @throws TooManyOpenSessionsException if the number of open sessions is exceeded.
     */
    String initiateSession(String username)
            throws SSOSessionException, TooManyOpenSessionsException;

    /**
     * This method accesss the session associated to the received id.
     * This resets the session last access time and updates the access count.
     *
     * @param sessionId the session id previously returned by initiateSession.
     * @throws NoSuchSessionException if the session id is not valid or the session is not valid.
     */
    void accessSession(String sessionId)
            throws NoSuchSessionException, SSOSessionException;

    /**
     * Gets an SSO session based on its id.
     *
     * @param sessionId the session id previously returned by initiateSession.
     * @throws org.josso.gateway.session.exceptions.NoSuchSessionException if the session id is not related to any sso session.
     */
    SSOSession getSession(String sessionId)
            throws NoSuchSessionException, SSOSessionException;

    /**
     * Gets all SSO sessions.
     */
    Collection getSessions()
            throws SSOSessionException;

    /**
     * Gets an SSO session based on the associated user.
     *
     * @param username the username used when initiating the session.
     * @throws org.josso.gateway.session.exceptions.NoSuchSessionException if the session id is not related to any sso session.
     */
    Collection getUserSessions(String username)
            throws NoSuchSessionException, SSOSessionException;

    /**
     * Invalidates all open sessions.
     */ 
    void invalidateAll()
        throws SSOSessionException;

    /**
     * Invalidates a session.
     *
     * @param sessionId the session id previously returned by initiateSession.
     * @throws org.josso.gateway.session.exceptions.NoSuchSessionException if the session id is not related to any sso session.
     */
    void invalidate(String sessionId)
        throws NoSuchSessionException, SSOSessionException;

    /**
     * Check all sessions and remove those that are not valid from the store.
     * This method is invoked periodically to update sessions state.
     */
    void checkValidSessions();

    /**
     * SessionStore instance is injected before initializing the manager.
     */
    void setSessionStore(SessionStore ss);

    /**
     * SessionIdGenerator instance is injected before initializing the manager.
     */
    void setSessionIdGenerator(SessionIdGenerator g);

    /**
     * Initialize this manager
     */
    void initialize();


    int getSessionCount() throws SSOSessionException;
}
