/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.agent;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.util.mbeans.JOSSOBaseMBean;

import javax.management.MBeanException;
import javax.management.Notification;
import javax.management.RuntimeOperationsException;

/**
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOAgentMBean.java,v 1.6 2006/02/09 16:53:05 sgonzalez Exp $
 */

public class SSOAgentMBean extends JOSSOBaseMBean {

    /**
     * String used as event type when notifying new partner app configurations using JMX.
     */
    public static final String JOSSO_AGENT_EVENT_ADD_PARTNER_APP = "josso.agent.addPartnerApp";

    /**
     * String used as event type when notifying partner app configuration removal using JMX.
     */
    public static final String JOSSO_AGENT_EVENT_REMOVE_PARTNER_APP = "josso.agent.removePartnerApp";


    private static final Log logger = LogFactory.getLog(SSOAgentMBean.class);

    private int _seq = 0;

    public SSOAgentMBean() throws MBeanException, RuntimeOperationsException {
        super();
    }

    public void addPartnerApp(String context, String[] ignoredWebResources) {

        if (context == null) {
            logger.warn("Tryint to add 'null' context as partner app.");
            return;
        }

        if (ignoredWebResources == null) {
            ignoredWebResources = new String[0];
        }

        SSOAgent a = getSSOAgent();
        SSOAgentConfiguration cfg = a.getConfiguration();
        cfg.addSSOPartnerApp(context, ignoredWebResources);

        SSOPartnerAppConfig[] papps = cfg.getSSOPartnerApps();
        for (int i = 0; i < papps.length; i++) {
            SSOPartnerAppConfig papp = papps[i];
            if (papp.getContext().equals(context)) {

                // Send a JMX notification, use parent ObjectName instance (oname).
                Notification n = new SSOAgentMBeanNotification(JOSSO_AGENT_EVENT_ADD_PARTNER_APP, oname, _seq++);
                n.setUserData(papp);

                try {
                    this.sendNotification(n);
                    return;

                } catch (MBeanException e) {
                    logger.warn("Can't send JMX notificatin : \n" + e.getMessage(), e);
                }
            }
        }

    }

    public void addPartnerApp(String context) {
        this.addPartnerApp(context, new String[0]);
    }

    public void removePartnerApp(String context) {

        if (context == null) {
            logger.warn("Trying to remove 'null' context");
            return;
        }
        SSOAgent a =getSSOAgent();
        a.getConfiguration().removeSSOPartnerApp(context);
        try {
            // Send a JMX notification, use parent ObjectName instance (oname).
            Notification n = new SSOAgentMBeanNotification(JOSSO_AGENT_EVENT_REMOVE_PARTNER_APP, oname, _seq++);
            n.setUserData(context);
            this.sendNotification(n);

        } catch (MBeanException e) {
            logger.warn("Can't send JMX notificatin : \n" + e.getMessage(), e);
        }
    }

    public SSOPartnerAppConfig[] listPartnerApps() {
        SSOAgent a = getSSOAgent();
        return a.getConfiguration().getSSOPartnerApps();
    }

    protected SSOAgent getSSOAgent() {
        return (SSOAgent) this.resource;
    }

    public class SSOAgentMBeanNotification extends Notification {

        public SSOAgentMBeanNotification(String type, Object source, long sequence) {
            super(type, source, sequence);
        }
    }

}
