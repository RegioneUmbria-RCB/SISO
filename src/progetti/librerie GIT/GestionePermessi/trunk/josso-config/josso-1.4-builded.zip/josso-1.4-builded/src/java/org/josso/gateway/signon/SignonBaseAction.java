/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.signon;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.Action;
import org.josso.Lookup;
import org.josso.auth.Credential;
import org.josso.auth.exceptions.SSOAuthenticationException;
import org.josso.auth.scheme.X509CertificateCredential;
import org.josso.gateway.*;
import org.josso.gateway.session.SSOSession;
import org.josso.gateway.session.exceptions.NoSuchSessionException;
import org.josso.util.SSOGatewayFactory;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
/**
 * This is the base action for all signon actions.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SignonBaseAction.java,v 1.17 2006/02/09 16:53:06 sgonzalez Exp $
 */
public abstract class SignonBaseAction extends Action implements Constants {

    private static final Log logger = LogFactory.getLog(SignonBaseAction.class);

    // private static final Log logger = LogFactory.getLog(SignonBaseAction.class);

    /**
     * Gets current sso gateway.
     */
    protected SSOGateway getSSOGateway() {

        SSOGateway g = (SSOGateway) getServlet().getServletContext().getAttribute(KEY_JOSSO_GATEWAY);

        if (g == null) {
            g = SSOGatewayFactory.getInstance().getNewSSOGateway();
            getServlet().getServletContext().setAttribute(KEY_JOSSO_GATEWAY, g);
        }
        return g;
    }

    /**
     * Gets the received SSO Command. If command is empty (""), returns null.
     */
    protected String getSSOCmd(HttpServletRequest request){
        String cmd = request.getParameter(PARAM_JOSSO_CMD);
        if ("".equals(cmd))
            cmd = null;
        return cmd;
    }

    protected SSOContext getNewSSOContext(HttpServletRequest request) throws SSOException, SSOAuthenticationException {

        // SSO Session
        String sessionId = getJossoSessionId(request);
        SSOSession s = null;

        if (sessionId != null && !"".equals(sessionId)) {
            try {
                s = getSSOGateway().findSession(sessionId);
            } catch (NoSuchSessionException e) {
                if (logger.isDebugEnabled())
                    logger.debug("NoSuchSessionException : " + sessionId);
            }
        }


        // TODO : Detect Authentication scheme when user is already logged.
        String scheme = null;
        Credential[] c = getCredentials(request);
        if (c.length > 0) {
            scheme = "basic-authentication";
            if (c[0] instanceof X509CertificateCredential) // TODO: hmm..ugly! this should be submitted by the LoginSelector
                scheme = "strong-authentication";
        }

        SSOContextImpl ctx = new SSOContextImpl();
        ctx.setCurrentSession(s);
        ctx.setUserLocation(request.getRemoteHost());
        ctx.setScheme(scheme);

        return ctx;
    }

    /**
     * Gets the josso session id value from the propper Cookie.
     * @param request
     * @return null, if JOSSO_SINGLE_SIGN_ON_COOKIE is not found in reqeust.
     */
    protected String getJossoSessionId(HttpServletRequest request) {
        Cookie c = getJossoCookie(request);
        if (c != null)
            return c.getValue();
        
        return null;
    }

    protected Cookie getJossoCookie(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        if (cookies == null)
            return null;

        for (int i = 0; i < cookies.length; i++) {
            Cookie cookie = cookies[i];
            if (cookie.getName().equals(Constants.JOSSO_SINGLE_SIGN_ON_COOKIE)) {
                return cookie;
            }
        }
        return null;

    }

    protected Cookie newJossoCookie(String value) throws Exception {
        SSOWebConfiguration cfg = Lookup.getInstance().lookupSSOWebConfiguration();
        // 2 - Store cookie with JOSSO cookie.
        Cookie ssoCookie = new Cookie(JOSSO_SINGLE_SIGN_ON_COOKIE, value);
        ssoCookie.setMaxAge(-1);
        ssoCookie.setPath("/");

        if (cfg.getSessionTokenScope() != null) {
            ssoCookie.setDomain(cfg.getSessionTokenScope());
        }

        if (cfg.isSessionTokenSecure()){
            ssoCookie.setSecure(true);
        }
        return ssoCookie;
    }


    /**
     * Subclasses should provide propper credentials based on specific authentication schemes.
     */
    protected Credential[] getCredentials(HttpServletRequest request) throws SSOAuthenticationException {
        return new Credential[0];
    }
}
