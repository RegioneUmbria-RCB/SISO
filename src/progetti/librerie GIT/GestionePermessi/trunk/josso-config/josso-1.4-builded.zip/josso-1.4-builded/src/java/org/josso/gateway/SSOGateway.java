/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway;

import org.josso.auth.Credential;
import org.josso.auth.exceptions.SSOAuthenticationException;
import org.josso.gateway.identity.SSORole;
import org.josso.gateway.identity.SSOUser;
import org.josso.gateway.session.SSOSession;
import org.josso.gateway.session.exceptions.NoSuchSessionException;

/**
 * SSO Gateway service interface.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOGateway.java,v 1.18 2006/02/09 16:53:06 sgonzalez Exp $
 */
public interface SSOGateway {

    /**
     * Login a user into the SSO infrastructure.
     *
     * @param credentials that proof user identity.
     * @param scheme the authentication scheme name to be used for
     *               logging in the user.
     * @param ctx the external context used during method execution
     *
     * @return the user information after login.
     *
     * @throws SSOException if an error occurs.
     * @throws SSOAuthenticationException if user identity cannot be confirmed.
     */
    SSOSession login(Credential[] credentials, String scheme, SSOContext ctx)
            throws SSOException, SSOAuthenticationException;

    /**
     * Builds the supplied user credentials for the
     * supplied Authentication Scheme.
     */
    Credential newCredential(String schemeName, String name, Object value)
            throws SSOAuthenticationException;

    /**
     * Obtains the principal name from the given credentials using the
     * supplied Authentication Scheme.
     */
    String getPrincipalName(String schemeName, Credential[] creds)
            throws SSOAuthenticationException;

    /**
     * Logout a user from the SSO infrastructure.
     * 
     * @param ctx the external context used during method execution
     *
     * @throws SSOException if an error occurs.
     *
     */
    void logout(SSOContext ctx)
            throws SSOException;

    /**
     * Finds a user based on session id, the user has to be logged in the SSO infrastructure.
     * @param sessionId
     *
     * @throws SSOException if user was not logged in the SSO.
     */
    SSOUser findUserInSession(String sessionId)
        throws SSOException;

    /**
     * List user's roles base on user's name.
     *
     * @param username
     *
     * @throws SSOException
     */
    SSORole[] findRolesByUsername(String username)
        throws SSOException;

    /**
     * Finds a session given its id.
     */ 
    SSOSession findSession(String jossoSessionId)
        throws SSOException, NoSuchSessionException;

    /**
     * Initializes this gateway.
     */
    void initialize();

    /**
     * Destroys this instance, free all resources.
     */
    void destroy();

    /**
     * @return true if the gateway was already initialized.
     */
    boolean isInitialized();

}
