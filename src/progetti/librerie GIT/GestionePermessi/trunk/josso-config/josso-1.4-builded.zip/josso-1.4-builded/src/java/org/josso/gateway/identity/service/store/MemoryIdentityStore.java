/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.identity.service.store;


import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.HierarchicalXMLConfiguration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.auth.Credential;
import org.josso.auth.CredentialKey;
import org.josso.gateway.SSONameValuePair;
import org.josso.gateway.identity.exceptions.NoSuchRoleException;
import org.josso.gateway.identity.exceptions.NoSuchUserException;
import org.josso.gateway.identity.exceptions.SSOIdentityException;
import org.josso.gateway.identity.service.BaseRole;
import org.josso.gateway.identity.service.BaseRoleImpl;
import org.josso.gateway.identity.service.BaseUser;
import org.josso.gateway.identity.service.BaseUserImpl;

import java.util.*;

/**
 * Memory based implementation of an IdentityStore and CredentialStore that reads
 * data from XML files.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: MemoryIdentityStore.java,v 1.19 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class MemoryIdentityStore extends AbstractStore {

    private static final Log logger = LogFactory.getLog(MemoryIdentityStore.class);

    // A map with BaseRole instances, the map key is the role name.
    private Map _roles;

    // A map with BaseUser instances, the key is the username.
    private Map _users;

    // Stores BaseRoles associated to each user.
    // The map key is the username.
    // The map value is a Set of rolenames.
    private Map _userRoles;

    // Stores credential values (Object) associated to each user.
    // The map key is the username.
    // THe map value is another Map with credetinals (name=key/value)
    private Map _principalCredentials;

    private boolean _initialized;


    private String _credentialsFileName;
    private String _usersFileName;

    public MemoryIdentityStore() {
        super();
        _users = new HashMap(7);
        _userRoles = new HashMap(11);
        _roles = new HashMap(11);
        _principalCredentials = new HashMap(11);
        _initialized = false;
    }

    /**
     * Initializes the store, reads data from XML files.
     */
    public synchronized void initialize() {
        try {
            // This store can work as an identityStore and as a credentialStore, so
            // configuration parameters are optional.
            if (_usersFileName != null)
                loadUsersData(_usersFileName);
            if (_credentialsFileName != null)
                loadCredentialsData(_credentialsFileName);
            _initialized = true;
        } catch (Exception e ) {
            logger.error(e, e);
            throw new RuntimeException("Can't initialize memory store : " + e.getMessage(), e);
        }
    }

    /**
     * Loads users from file.
     * @param fName the file containing user definitions.
     */
    protected void loadUsersData(String fName) throws Exception{
        // First, users
        logger.info("Reading users from : " + fName);
        HierarchicalXMLConfiguration config;
        config = new HierarchicalXMLConfiguration ();
        //config.setFileName(fName);
        config.load(getClass().getResource("/" + fName));

        loadRoles(config);

        loadUsers(config);

    }

    protected void loadRoles(Configuration config) {

        if (config.getList("roles.role.name").size() < 1)
            return;

        Collection c = null;

        // Load Roles
        if (!(config.getProperty("roles.role.name") instanceof java.util.Collection))
        {
            List nCol = new ArrayList();
            nCol.add(config.getProperty("roles.role.name"));
            c = nCol;
        } else
            c = (Collection)config.getProperty("roles.role.name");

        for(int i=0; i < c.size(); i++) {
            String name = config.getString("roles.role(" + i + ").name");
            BaseRole role = createRole(name);
            RoleKey key = createRoleKey(role);
            _roles.put(key, role);
            logger.info("Role : " + role);
        }
    }

    protected void loadUsers(Configuration config) throws Exception {

        // Load Users
        Collection c = null;
        if (!(config.getProperty("users.user.name") instanceof java.util.Collection))
        {
            List nCol = new ArrayList();
            nCol.add(config.getProperty("users.user.name"));
            c = nCol;
        } else
            c = (Collection)config.getProperty("users.user.name");

        for(int i=0; i < c.size(); i++) {
            String name = config.getString("users.user(" + i + ").name");
            BaseUser user = createUser(name);
            UserKey key = createUserKey(user);
            _users.put(key, user);
            logger.info("User : " + user);

            // Load user properties
            SSONameValuePair[] props = loadUserProperties(config.subset("users.user(" + i + ")"));
            user.setProperties(props);

            // Load user roles, optional
            if (config.getList("users.user(" + i + ").roles").size() > 0) {

                String roles = config.getString("users.user(" + i + ").roles");
                StringTokenizer st = new StringTokenizer(roles != null ? roles : "", ",");
                while(st.hasMoreTokens()) {
                    String roleName = st.nextToken().trim();
                    BaseRole role = findRoleByName(roleName);
                    RoleKey roleKey = createRoleKey(role);
                    assignRole(key, roleKey);
                    logger.info("User is in role : " + role);
                }
            }
        }
    }

    protected SSONameValuePair[] loadUserProperties(Configuration config) {

        if (config.getList("properties.property.name").size() < 1)
            return new SSONameValuePair[0];

        Collection c = null;
        if (!(config.getProperty("properties.property.name") instanceof java.util.Collection))
        {
            List nCol = new ArrayList();
            nCol.add(config.getProperty("properties.property.name"));
            c = nCol;
        } else
            c = (Collection)config.getProperty("properties.property.name");

        ArrayList props = new ArrayList(c.size());
        for(int i=0; i < c.size(); i++) {
            String name = config.getString("properties.property(" + i + ").name");
            String value = config.getString("properties.property("+ i + ").value");
            SSONameValuePair p = new SSONameValuePair(name, value);
            props.add(p);
            logger.info("Property : " + name + "=" + value);
        }
        return (SSONameValuePair[]) props.toArray(new SSONameValuePair[props.size()]);

    }

    /**
     * Loads credentials from file.
     * @param fName the file containing user definitions.
     */
    protected void loadCredentialsData(String fName) throws Exception{
        logger.info("Reading credentials from : " + fName);

        HierarchicalXMLConfiguration config;
        config = new HierarchicalXMLConfiguration ();
        //config.setFileName(fName);
        config.load(getClass().getResource("/" + fName));

        loadCredentialSet(config);

    }

    protected void loadCredentialSet(Configuration config) throws Exception {
        // Load Credentials
        Collection c = null;
        if (!(config.getProperty("credential-set.key") instanceof java.util.Collection))
        {
            List nCol = new ArrayList();
            nCol.add(config.getProperty("credential-set.key"));
            c = nCol;
        } else
            c = (Collection)config.getProperty("credential-set.key");

        for(int i=0; i < c.size(); i++) {
            String keyName = config.getString("credential-set(" + i + ").key");
            logger.info("Credential-set : " + keyName);
            Credential[] creds = loadCredentials(config.subset("credential-set("+i+")"));
            CredentialKey key = createCredentialKey(keyName);
            addCredentials(key, creds);
        }

    }

    protected Credential[] loadCredentials(Configuration config) throws Exception {
        if (config.getList("credential.name").size() < 1)
            return new Credential[0];

        Collection c = null;
        if (!(config.getProperty("credential.name") instanceof java.util.Collection))
        {
            List nCol = new ArrayList();
            nCol.add(config.getProperty("credential.name"));
            c = nCol;
        } else
            c = (Collection)config.getProperty("credential.name");

        List creds = new ArrayList();
        for (int i=0; i < c.size() ; i++) {
            String name = config.getString("credential("+i+").name");
            String value = config.getString("credential("+i+").value");
            logger.info("Credential : " + name + "=*");
            creds.add(getAuthenticationScheme().newCredential(name, value));
        }
        return (Credential[]) creds.toArray(new Credential[creds.size()]);
    }

    // ------------------------------------------------------------------------------
    // IdentityStore
    // ------------------------------------------------------------------------------

    // BaseUser related methods.

    public synchronized BaseUser loadUser(UserKey key) throws NoSuchUserException, SSOIdentityException {
        // TODO : This should be added to the store lifecycle
        if (!_initialized)
            initialize();

        BaseUser user = (BaseUser) _users.get(key);
        if (user == null)
            throw new NoSuchUserException(key);

        if (logger.isDebugEnabled())
            logger.debug("[load(" + key + ")] : ok");

        return user;
    }

    /**
     * @param key
     *
     * @throws SSOIdentityException
     */
    public synchronized BaseRole[] findRolesByUserKey(UserKey key)
            throws SSOIdentityException {

        // TODO : This should be added to the store lifecycle
        if (!_initialized)
            initialize();

        Set roles = new HashSet();
        Set roleKeys = (Set) _userRoles.get(key);

        Iterator it = roleKeys.iterator();
        while (it.hasNext()) {
            RoleKey roleKey = (RoleKey) it.next();
            roles.add(loadRole(roleKey));
        }

        return (BaseRole[]) roles.toArray(new BaseRole[roles.size()]);
    }
    // ------------------------------------------------------------------------------
    // CredentialStore
    // ------------------------------------------------------------------------------
    /**
     * Gets configured credentials for this principal.
     *
     * @param key used to retrieve this credentials.
     * @throws SSOIdentityException
     */
    public Credential[] loadCredentials(CredentialKey key) throws SSOIdentityException {

        // TODO : This should be added to the store lifecycle
        if (!_initialized)
            initialize();

        Set c = (Set) _principalCredentials.get(key);
        if (c == null) {
            logger.info("No credentials found for principal : " + key);
            return new Credential[0];
        }

        return (Credential[]) c.toArray(new Credential[c.size()]);
    }

    // ------------------------------------------------------------------------------
    // utils ....
    // ------------------------------------------------------------------------------
    protected void addCredentials(CredentialKey key, Credential[] c) {
        for (int i = 0; i < c.length; i++) {
            Credential credential = c[i];
            addCredential(key, credential);
        }
    }

    protected void addCredential(CredentialKey key, Credential c) {
        Set credentials = (Set) _principalCredentials.get(key);
        if (credentials == null) {
            credentials = new HashSet();
            _principalCredentials.put(key, credentials);
        }

        credentials.add(c);

    }

    protected CredentialKey createCredentialKey(String name) {
        // TODO : Use propper key adapter.
        return new SimpleUserKey(name);
    }

    public synchronized Set getRoleKeys()
            throws SSOIdentityException {
        return _roles.keySet();
    }

    public synchronized BaseRole loadRole(RoleKey roleKey)
            throws NoSuchRoleException, SSOIdentityException {
        BaseRole role = (BaseRole) _roles.get(roleKey);
        if (role == null)
            throw new NoSuchRoleException(roleKey);

        return role;
    }

    public synchronized void saveUser(BaseUser user) throws SSOIdentityException {
        BaseUser old = (BaseUser) _users.put(new SimpleUserKey(user.getName()), user);

        if (logger.isDebugEnabled())
            logger.debug("[save(" + user + ")] : ok");

        if (logger.isDebugEnabled())
            logger.debug("[save(" + user + ")] : User " + (old != null ? "" : " not") + " replaced");
    }

    public synchronized void removeUser(UserKey key) throws NoSuchUserException, SSOIdentityException {
        BaseUser old = (BaseUser) _users.remove(key);
        if (old == null)
            throw new NoSuchUserException(key);

        // Reomve roles
        _userRoles.remove(key);

        if (logger.isDebugEnabled())
            logger.debug("[remove(" + key + ")] : ok");
    }

    public synchronized BaseRole findRoleByName(String name) throws SSOIdentityException{
        for (Iterator it = _roles.values().iterator() ; it.hasNext() ; ) {
            BaseRole role = (BaseRole) it.next();
            if (role.getName().equals(name))
                return role;
        }
        throw new SSOIdentityException("No such role : " + name);
    }

    public synchronized void removeRole(RoleKey key)
            throws NoSuchRoleException, SSOIdentityException {
        BaseRole role = (BaseRole) _roles.remove(key);
        if (role == null)
            throw new NoSuchRoleException(key);

        // Check all userroles ...
        Iterator it = _userRoles.values().iterator();
        while (it.hasNext()) {
            Set roleKeys = (Set) it.next();
            roleKeys.remove(key);
        }

    }

    public synchronized void saveRole(BaseRole role) throws SSOIdentityException {
        _roles.put(new SimpleRoleKey(role.getName()), role);
    }

    public synchronized void assignRole(UserKey userKey, RoleKey roleKey)
            throws SSOIdentityException {

        Set roles = (Set) _userRoles.get(userKey);
        if (roles == null) {
            roles = new HashSet();
            _userRoles.put(userKey, roles);
        }
        roles.add(roleKey);
    }

    public synchronized void deasignRole(UserKey userKey, RoleKey roleKey)
            throws SSOIdentityException {

        Set roles = (Set) _userRoles.get(userKey);
        if (roles == null)
            return;

        roles.remove(roleKey);
    }


    // -----------------------------------------------------------------------------------------
    // Private Utils.
    // -----------------------------------------------------------------------------------------

    protected BaseUser createUser(String username) {

        BaseUser user = new BaseUserImpl();
        UserKey key = new SimpleUserKey(username);
        user.setName(username);

        _users.put(key, user);
        return user;

    }

    protected UserKey createUserKey(BaseUser user) {
        // TODO : Use propper key adapter ...
        return new SimpleUserKey(user.getName());
    }

    protected BaseRole createRole(String name) {
        BaseRole role = new BaseRoleImpl();
        role.setName(name);
        return role;
    }

    protected RoleKey createRoleKey(BaseRole role) {
        // TODO : Use propper key adapter ...
        return new SimpleRoleKey(role.getName());
    }

    /**
     * Creates a credential for the specific value.
     *
     * @param name  the credential name (i.e. username, password, challenge, etc.)
     * @param value
     *
     */
    protected Credential doMakeCredential(String name, Object value)
            throws SSOIdentityException {

        return getAuthenticationScheme().newCredential(name, value);
    }

    // ---------------------------------------------------------------------
    // Configuration properties
    // ---------------------------------------------------------------------

    public void setCredentialsFileName(String credentialsFileName) {
        logger.debug("Setting crednetials file name to : " + credentialsFileName);
        _credentialsFileName = credentialsFileName;
    }

    public String getCredentialsFileName() {
        return _credentialsFileName;
    }

    public void setUsersFileName(String usersFileName) {
        logger.debug("Setting users file name to : " + usersFileName);
        _usersFileName = usersFileName;
    }

}
