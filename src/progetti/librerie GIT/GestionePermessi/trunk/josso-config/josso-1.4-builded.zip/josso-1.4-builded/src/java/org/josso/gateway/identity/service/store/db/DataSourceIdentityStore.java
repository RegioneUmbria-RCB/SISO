/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.identity.service.store.db;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.gateway.identity.exceptions.SSOIdentityException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * DataSource based implementation of a DB Identity and Credential store. 
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: DataSourceIdentityStore.java,v 1.11 2006/02/16 22:29:20 sgonzalez Exp $
 */
public class DataSourceIdentityStore extends AbstractDBIdentityStore {

    private static final Log logger = LogFactory.getLog(DataSourceIdentityStore.class);

    private String _dsJndiName;
    private DataSource _datasource;


    // ------------------------------------------------------------------
    // Configuration properties.
    // ------------------------------------------------------------------

    /**
     * Sets the JNDI name of the DS associated to this Store.
     * @param dsJndiName the JNDI name of the datasource used by the store.
     */
    public void setDsJndiName(String dsJndiName) {
        _dsJndiName = dsJndiName;
        _datasource = null; // clear the previous reference to the DS.
    }

    // --------------------------------------------------------------------------
    // Proteced utils
    // --------------------------------------------------------------------------

    /**
     * Lazy load the datasource instace used by this store.
     *
     *
     * @throws SSOIdentityException
     */
    protected DataSource getDataSource() throws SSOIdentityException {

        if (_datasource == null) {

            try {

                if (logger.isDebugEnabled()) logger.debug("[getDatasource() : ]" + _dsJndiName);

                InitialContext ic = new InitialContext();
                _datasource = (DataSource) ic.lookup(_dsJndiName);

            } catch (NamingException ne) {
                logger.error("Error during DB connection lookup", ne);
                throw new SSOIdentityException(
                    "Error During Lookup\n" + ne.getMessage());
            }

        }

        return _datasource;
    }

    /**
     * Opens a new DB Connection, retrieved from the DS.
     *
     * @throws SSOIdentityException
     */
    protected Connection getDBConnection() throws SSOIdentityException {
        try {
            return getDataSource().getConnection();
        } catch (SQLException e) {
            logger.error("[getDBConnection()]:" + e.getErrorCode() + "/" + e.getSQLState() + "]" + e.getMessage());
            throw new SSOIdentityException(
                "Exception while getting connection: \n " + e.getMessage());
        }
    }


}
