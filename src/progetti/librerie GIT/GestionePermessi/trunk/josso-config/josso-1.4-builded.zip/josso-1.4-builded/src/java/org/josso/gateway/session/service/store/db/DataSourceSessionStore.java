/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.session.service.store.db;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.gateway.session.exceptions.SSOSessionException;

/**
 * A DB session store that uses a DataSource to obtain connections to the DB server.
 * The only configuration property specific to this implementation is the datasource JNDI name.
 * See DbSessionStore for more configuration details.
 *
 * @see DbSessionStore
 *
 * @author Jeff Gutierrez (code@gutierrez.ph)
 *
 */
public class DataSourceSessionStore extends DbSessionStore
{
    private static final Log logger = LogFactory.getLog( DataSourceSessionStore.class );

    private String _dsJndiName;
    private DataSource _datasource;

    
    /**
     * @return A db Connection.
     */
	protected Connection getConnection() throws SQLException, SSOSessionException
	{
		final Connection conn = getDataSource().getConnection();
		conn.setAutoCommit( false );
		
		return conn;
	}

	
    // ------------------------------------------------------------------
    // Configuration properties.
    // ------------------------------------------------------------------

    /**
     * Sets the JNDI name of the DS associated to this Store.
     * @param dsJndiName the JNDI name of the datasource used by the store.
     */
    public void setDsJndiName(String dsJndiName) 
    {
        _dsJndiName = dsJndiName;
        _datasource = null; // Clear the previous reference to the DS.
    }

    public String getDsJndiName() {
        return _dsJndiName;
    }

    // --------------------------------------------------------------------------
    // Proteced utils
    // --------------------------------------------------------------------------

    /**
     * Lazy load the datasource instace used by this store.
     *
     *
     * @throws SSOSessionException
     */
    protected synchronized DataSource getDataSource() throws SSOSessionException 
    {
        if( _datasource == null ) 
        {
            try 
            {
                if (logger.isDebugEnabled()) 
                	logger.debug("[getDatasource() : ]" + _dsJndiName);

                InitialContext ic = new InitialContext();
                _datasource = (DataSource) ic.lookup( _dsJndiName );

            } 
            catch( NamingException ne) 
            {
                logger.error("Error during DB connection lookup", ne);
                throw new SSOSessionException(
                    "Error During Lookup\n" + ne.getMessage());
            }

        }

        return _datasource;
    }
	
}
