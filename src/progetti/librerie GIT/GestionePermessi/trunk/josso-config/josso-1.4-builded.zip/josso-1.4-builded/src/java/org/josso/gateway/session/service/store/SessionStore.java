/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.session.service.store;

import org.josso.gateway.session.exceptions.SSOSessionException;
import org.josso.gateway.session.service.BaseSession;

import java.util.Date;

/**
 * Represents a resource to store sessions.
 * Implementations define the specific persistence mechanism to store sessions.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SessionStore.java,v 1.9 2006/03/20 22:06:44 sgonzalez Exp $
 */

public interface SessionStore {

     /**
      * Return the number of Sessions present in this Store.
      *
      */
     int getSize() throws SSOSessionException;


     /**
      * Return an array containing the session identifiers of all Sessions
      * currently saved in this Store.  If there are no such Sessions, a
      * zero-length array is returned.
      *
      */
     String[] keys() throws SSOSessionException;

     /**
      * Return an array of all BaseSessions in this store.  If there are no
      * sessions, then return a zero-length array.
      */
     BaseSession[] loadAll() throws SSOSessionException;
     
     /**
      * Load and return the BaseSession associated with the specified session
      * identifier from this Store, without removing it.  If there is no
      * such stored BaseSession, return <code>null</code>.
      *
      * @param id BaseSession identifier of the session to load
      *
      */
     BaseSession load(String id)
         throws SSOSessionException;

    /**
     * Load and return the BaseSession associated with the specified username
     * from this Store, without removing it.  If there is no
     * such stored BaseSession, return <code>null</code>.
     *
     * @param name username of the session to load
     *
     */
    BaseSession[] loadByUsername(String name)
        throws SSOSessionException;

    /**
     * Load and return the BaseSessions whose last access time is less than the received time
     */
    BaseSession[] loadByLastAccessTime(Date time) throws SSOSessionException;

    /**
     * Load and return the BaseSessions whose valid property is equals to the valid argument.
     */
    BaseSession[] loadByValid(boolean valid) throws SSOSessionException;

     /**
      * Remove the BaseSession with the specified session identifier from
      * this Store, if present.  If no such BaseSession is present, this method
      * takes no action.
      *
      * @param id BaseSession identifier of the BaseSession to be removed
      *
      */
     void remove(String id) throws SSOSessionException;


     /**
      * Remove all Sessions from this Store.
      */
     void clear() throws SSOSessionException;

     /**
      * Save the specified BaseSession into this Store.  Any previously saved
      * information for the associated session identifier is replaced.
      *
      * @param session BaseSession to be saved
      */
     void save(BaseSession session) throws SSOSessionException;





}
