<?php
/**
 * JOSSO Agent class definition.
 *
 * @package org.josso.agent.php
 */

/**
 Copyright (c) 2005-2006, Novascope S.A. and the JOSSO team
 All rights reserved.
 Redistribution and use in source and binary forms, with or
 without modification, are permitted provided that the following
 conditions are met:

 * Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

 * Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in
   the documentation and/or other materials provided with the
   distribution.

 * Neither the name of the JOSSO team nor the names of its
   contributors may be used to endorse or promote products derived
   from this software without specific prior written permission.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 POSSIBILITY OF SUCH DAMAGE.

*/

/**
 * Include NUSOAP soap client.
 */
require_once('nusoap/nusoap.php');

/**
 * PHP Josso Agent implementation based on WS.
 *
 * @package  org.josso.agent.php
 *
 * @author Sebastian Gonzalez Oyuela <sgonzalez@josso.org>
 * @version $Id: class.jossoagent.php,v 1.3 2006/02/14 21:18:44 sgonzalez Exp $
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 *
 */
class jossoagent  {


	// ---------------------------------------
	// JOSSO Agent configuration : 
	// --------------------------------------- 
	
	/**
	 * WS End-point
	 * @var string
	 * @access private
	 */
	var $endpoint = 'http://localhost:8080';
	
	/**
	 * WS Proxy Settings
     * @var string
     * @access private
     */
	var $proxyhost = '';

	/**
     * @var string
     * @access private
     */
	var $proxyport = '';

	/**
     * @var string
     * @access private
     */
	var $proxyusername = '';

	/**
     * @var string
     * @access private
     */
	var $proxypassword = '';
	
	// Gateway
    /**
     * @var string
     * @access private
     */
	var $gatewayLoginUrl;

	/**
     * @var string
     * @access private
     */
	var $gatewayLogoutUrl;

	/**
     * @var string
     * @access private
     */
	var $sessionAccessMinInterval = 1000;

	// ---------------------------------------
	// JOSSO Agent internal state : 
	// --------------------------------------- 

	/**
	 * SOAP Clienty for identity mgr.
     * @var string
     * @access private
     */
	var $identityMgrClient;
	
	/**
	 * SOAP Clienty for session mgr.
     * @var string
     * @access private
     */
	var $sessionMgrClient;
	
	/**
	 * Last occurred error
     * @var string
     * @access private
     */
	var $fault;

	/**
	 * Last occurred fault
     * @var string
     * @access private
     */
	var $err;
	
	/**
	 * @return jossoagent a new Josso PHP Agent instance.
	 */
	function getNewInstance() {
		// Get config variable values from josso.inc.
		global $josso_gatewayLoginUrl, $josso_gatewayLogoutUrl, $josso_endpoint, $josso_proxyhost, $josso_proxyport, $josso_proxyusername, $josso_proxypassword;
		
		return new jossoagent($josso_gatewayLoginUrl, 
							  $josso_gatewayLogoutUrl, 
							  $josso_endpoint, 
							  $josso_proxyhost, 
							  $josso_proxyport, 
							  $josso_proxyusername, 
							  $josso_proxypassword);	
	}
	
	/**
	* constructor
	*
	* @access private
	*
	* @param    string $josso_gatewayLoginUrl 
	* @param    string $josso_gatewayLogoutUrl 
	* @param    string $josso_endpoint SOAP server
	* @param    string $josso_proxyhost
	* @param    string $josso_proxyport
	* @param    string $josso_proxyusername
	* @param    string $josso_proxypassword
	*/
	function jossoagent($josso_gatewayLoginUrl, $josso_gatewayLogoutUrl, $josso_endpoint, 
						$josso_proxyhost, $josso_proxyport, $josso_proxyusername, $josso_proxypassword) {
	
		// WS Config
		$this->endpoint = $josso_endpoint;
		$this->proxyhost = $josso_proxyhost;
		$this->proxyport = $josso_proxyport;
		$this->proxyusername = $josso_proxyusername;
		$this->proxypassoword = $josso_proxypassword;
		
		// Agent config
		$this->gatewayLoginUrl = $josso_gatewayLoginUrl;
		$this->gatewayLogoutUrl = $josso_gatewayLogoutUrl;
		
		if (isset($josso_sessionAccessMinInterval)) {
			$this->sessionAccessMinInterval = $josso_sessionAccessMinInterval;
		}
										
	}
	
	/**
	* Gets the authnenticated jossouser, if any.
	*
	* @return jossouser the authenticated user information.
	* @access public
	*/
	function getUserInSession() {
	
		$sessionId = $this->getSessionId();
		if (!isset($sessionId)) {
			return ;
		}

		// SOAP Invocation
		$soapclient = $this->getIdentityMgrSoapClient();
		$result = $soapclient ->call('findUserInSession', array('in0' => $sessionId));
		
		if (! $this->checkError($soapclient)) {
			return $this->newUser($result);
		}
		
	}
	
	/**
	* Returns true if current authenticated user is associated to the received role.
	* If no user is logged in, returns false.
    *
	* @param string $rolename the name of the role.
	*
	* @return bool
	* @access public
	*/
	function isUserInRole($rolename) {
		$user = $this->getUserInSession();
		if (!isset($user)) {
			return false;
		}
		
		$roles = $this->findRolesByUsername($user->getName()) ;
		
		foreach($roles as $role) {
			if ($role->getName() == $rolename) 
				return TRUE;
		}
		return FALSE;
	}
	
	/**
	* Returns all roles associated to the given username.
	*
	* @return jossorole[] an array with all jossorole instances
	* @access public
	*/
	function findRolesByUsername ($username) {
	
		// SOAP Invocation
		$soapclient = $this->getIdentityMgrSoapClient();
		$result = $soapclient->call('findRolesByUsername', array('in0' => $username));
		if (! $this->checkError($soapclient)) {
			// Build array of roles
			$i = 0;
			foreach($result as $roledata) {
				$roles[$i] = $this->newRole($roledata);
				$i++;
			}
			return $roles;
		}
		
	}
	
	/**
	 * Sends a keep-alive notification to the SSO server so that SSO sesison is not lost.
	 * @access public
	 */
	function accessSession() {
	
		// Check if a session ID is pressent.
		$sessionId = $this->getSessionid();
		if (!isset($sessionId )) {
			return;
		}
		// Check last access time :
		$lastAccessTime = $_SESSION['JOSSO_LAST_ACCESS_TIME'];
		$now = time();
		// Assume that _SESSION is set.
		if (!isset($lastAccessTime) || $lastAccessTime + $this->sessionAccessMinInterval < $now ) {
			$_SESSION['JOSSO_LAST_ACCESS_TIME'] = $now;
			$soapclient = $this->getSessionMgrSoapClient();
			$result = $soapclient->call('accessSession', array('in0' => $sessionId));
			$this->checkError($soapclient) ;
		}
		
	}
	
	/**
	 * Returns the URL where the user should be redireted to authenticate.
	 *
	 * @return string the configured login url.
	 *
	 * @access public
	 */
	function getGatewayLoginUrl() {
		return $this->gatewayLoginUrl;
	}
	
	/**
	 * Returns the URL where the user should be redireted to logout.
	 *
     * @return string the configured logout url.
     *
     * @access public
	 */
	function getGatewayLogoutUrl() {
		return $this->gatewayLogoutUrl;
	}

	
	/**
	 * Allows client applications to access error messages
	 *
	 * @access public
	 */
	function getError() {
		return $this->err;
	}
	
	/**
	 * Allows client applications to access error messages
	 *
	 * @access public
	 */
	function getFault() {
		return $this->fault;
	}
	
	//----------------------------------------------------------------------------------------
	// Protected methods intended to be invoked only within this class or subclasses.
	//----------------------------------------------------------------------------------------
	
	/**
	 * Gets current JOSSO session id, if any.
	 *
	 * @access private
	 */
	function getSessionId() {
		return $_COOKIE['JOSSO_SESSIONID'];
	}
	
	/**
	 * Factory method to build a user from soap data.
	 *
	 * @param array user information as received from WS.
	 * @return jossouser a new jossouser instance.
	 *
	 * @access private
	 */
	function newUser($data) {
		// Build a new jossouser 
		$username = $data['name'];
		$properties = $data['properties'];

		$user = new jossouser($username, $properties);
		
		return $user;
	}
	
	/**
	 * Factory method to build a role from soap data.
	 *
	 * @param array role information as received from WS.
	 * @return jossorole a new jossorole instance
	 *
	 * @access private
	 */
	function newRole($data) {
		// Build a new jossouser 
		$rolename = $data['name'];
		$role = new jossorole($rolename);
		return $role;
	}
	
	/**
	 * Checks if an error occured with the received soapclient and stores information in agent state.
	 *
	 * @access private
	 */
	function checkError($soapclient) {
		// Clear old error/fault information.
		unset($this->fault);				
		unset($this->err);

		// Check for a fault
		if ($soapclient->fault) {
			$this->fault = $soapclient->fault;
			return TRUE;
		} else {
			// Check for errors
			$err = $soapclient->getError();
			if ($err) {
				$this->err = $soapclient->getError();
				return TRUE;
			} 
		}
		
		// No errors ...
		return FALSE;
	
	}
	
	/**
	 * Gets the soap client to access identity service.
	 *
	 * @access private
	 */
	function getIdentityMgrSoapClient() {
		// Lazy load the propper soap client
		if (!isset($this->identityMgrClient)) {
			$this->identityMgrClient = new soapclient($this->endpoint . '/josso/services/SSOIdentityManager?wsdl', true,
											$this->proxyhost, $this->proxyport, $this->proxyusername, $this->proxypassword);

            // Sets default encoding to UTF-8 ...
            $this->identityMgrClient->soap_defencoding = 'UTF-8';
            $this->identityMgrClient->decodeUTF8(false);
		}
		return $this->identityMgrClient;
	}
	
	/**
	 * Gets the soap client to access session service.
	 *
	 * @access private
	 */
	function getSessionMgrSoapClient() {
		// Lazy load the propper soap client
		if (!isset($this->sessionMgrClient)) {
			// SSOSessionManager SOAP Client
			$this->sessionMgrClient = new soapclient($this->endpoint . '/josso/services/SSOSessionManager?wsdl', true,
										$this->proxyhost, $this->proxyport, $this->proxyusername, $this->proxypassword);
		}
		return $this->sessionMgrClient;

	}

}
?>
