/**
 * SSOEventManagerClient.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jul 21, 2005 (10:26:06 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.event.client.ws.impl;

public interface SSOEventManagerClient extends java.rmi.Remote {
    public void fireSessionEvent(java.lang.String in0, java.lang.String in1, java.lang.String in2, java.lang.Object in3) throws java.rmi.RemoteException, org.josso.gateway.event.client.ws.impl.SSOEventException;
    public void fireSSOEvent(org.josso.gateway.event.client.ws.impl.SSOEvent in0) throws java.rmi.RemoteException, org.josso.gateway.event.client.ws.impl.SSOEventException;
}
