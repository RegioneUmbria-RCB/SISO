/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */

package org.josso.gateway.signon;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.*;
import org.josso.Lookup;
import org.josso.gateway.SSOContext;
import org.josso.gateway.SSOException;
import org.josso.gateway.SSOGateway;
import org.josso.gateway.SSOWebConfiguration;
import org.josso.gateway.identity.SSOUser;
import org.josso.gateway.session.SSOSession;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: LogoutAction.java,v 1.10 2006/02/15 15:43:24 sgonzalez Exp $
 */

public class LogoutAction extends SignonBaseAction {

    private static final Log logger = LogFactory.getLog(LogoutAction.class);

    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {
        SSOSession session = null;
        SSOUser user = null;

        try {

            // Logout user
            SSOGateway g = getSSOGateway();
            SSOContext ctx = getNewSSOContext(request);
            session = ctx.getCurrentSession();
            user = g.findUserInSession(session.getId());

            // Clear josso cookie
            Cookie ssoCookie = newJossoCookie("-");
            response.addCookie(ssoCookie);

            g.logout(ctx);

        } catch (SSOException e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage(), e);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            ActionErrors errors = new ActionErrors();
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError("sso.login.failed"));
            saveErrors(request, errors);
        }

        // Redirect the user to the propper page, if any
        String back_to = request.getParameter(PARAM_JOSSO_BACK_TO);

        if (back_to == null) {
            // Try with the configured URL if any.
            SSOWebConfiguration c = Lookup.getInstance().lookupSSOWebConfiguration();
            back_to = c.getLogoutBackToURL();
        }

        if (back_to != null) {
            if (logger.isDebugEnabled())
                logger.debug("[logout()], ok->redirecting to : " + back_to);
            response.sendRedirect(response.encodeRedirectURL(back_to));
            return null; // No forward is needed.
        }

        if (logger.isDebugEnabled())
            logger.debug("[logout()], ok");

        return mapping.findForward("success");
    }

}
