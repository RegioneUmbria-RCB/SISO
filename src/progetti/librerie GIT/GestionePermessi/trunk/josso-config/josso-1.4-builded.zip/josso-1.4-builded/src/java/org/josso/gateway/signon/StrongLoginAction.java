/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.signon;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.auth.Credential;
import org.josso.auth.exceptions.SSOAuthenticationException;
import org.josso.gateway.SSOGateway;

import javax.servlet.http.HttpServletRequest;
import java.security.cert.X509Certificate;

/**
 * Strong Authentication Struts Action which instantiates the Credentials using the
 * X.509 Certificate provided in the Http Request.
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: StrongLoginAction.java,v 1.7 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class StrongLoginAction extends LoginAction {

    private static final Log logger = LogFactory.getLog(StrongLoginAction.class);

    /**
     * Obtain the X.509 Certificate from the Request.
     * <p/>
     * In order for strong authentication to work, the SSL connection must be established
     * in client authentication mode, so that client certificates are sent to the server.
     *
     * @param request
     * @throws SSOAuthenticationException
     */
    protected Credential[] getCredentials(HttpServletRequest request) throws SSOAuthenticationException {

        String cipherSuite = (String) request.getAttribute
                ("javax.servlet.request.cipher_suite");

        if (cipherSuite != null) {
            X509Certificate certChain[] =

                    (X509Certificate[]) request.getAttribute("javax.servlet.request.X509Certificate");

            if (certChain != null && certChain.length >= 1) {
                SSOGateway g = getSSOGateway();
                Credential x509_certificate = g.newCredential("strong-authentication",
                        "userCertificate",
                        certChain[0]
                );
                Credential[] c = {x509_certificate};

                return c;
            } else
                logger.error("No X.509 Certificate Received");
        } else
            logger.error("An SSL Connection is Required to perform Strong Authentication");

        return new Credential[0];
    }
}
