/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.Lookup;
import org.josso.SecurityDomain;
import org.josso.auth.Authenticator;
import org.josso.auth.Credential;
import org.josso.auth.SimplePrincipal;
import org.josso.auth.exceptions.AuthenticationFailureException;
import org.josso.auth.exceptions.SSOAuthenticationException;
import org.josso.gateway.event.security.SSOSecurityEventManager;
import org.josso.gateway.identity.SSORole;
import org.josso.gateway.identity.SSOUser;
import org.josso.gateway.identity.exceptions.SSOIdentityException;
import org.josso.gateway.identity.service.SSOIdentityManager;
import org.josso.gateway.session.SSOSession;
import org.josso.gateway.session.exceptions.NoSuchSessionException;
import org.josso.gateway.session.exceptions.SSOSessionException;
import org.josso.gateway.session.service.SSOSessionManager;

import javax.security.auth.Subject;
import java.security.Principal;
import java.util.Set;

/**
 * This is the default SSO Gateway implementation.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOGatewayImpl.java,v 1.27 2006/03/20 22:06:43 sgonzalez Exp $
 */
public class SSOGatewayImpl implements SSOGateway{

    private static final Log logger = LogFactory.getLog(SSOGatewayImpl.class);

    private boolean _initialized;

    public SSOGatewayImpl() {

    }

    /**
     * This method logins a user into de SSO infrastructure.
     *
     * @param cred the user credentials used as user identity proof.
     * @param scheme the authentication scheme name to be used for logging in the user.
     *
     * @throws SSOAuthenticationException if authentication fails.
     * @throws SSOException if an error occurs.
     */
    public SSOSession login(Credential[] cred, String scheme, SSOContext ctx)
            throws SSOException, SSOAuthenticationException {

        try {

            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();

            // Configure this ...!
            SSOIdentityManager im = domain.getIdentityManager();
            SSOSessionManager sm = domain.getSessionManager();
            Authenticator au = domain.getAuthenticator();

            // 1. Invalidate current session
            SSOSession currentSession = ctx.getCurrentSession();
            if (currentSession != null) {
                try {
                    if (logger.isDebugEnabled())
                        logger.debug("Invalidating existing session : " + currentSession.getId());
                    sm.invalidate(currentSession.getId());
                } catch (Exception e) {
                    logger.warn("Can't ivalidate current session : " + currentSession.getId() + "\n" + e.getMessage() ,e);
                }
            }

            // 2. Authenticate using credentials :
            Subject s = au.check(cred, scheme);
            Set principals = s.getPrincipals(SimplePrincipal.class);
            if (principals.size() != 1) {
                // The Set should NEVER be empty or have more than one Principal ...
                // In the future, we could have more than one principal if authenticated with multiple schemes.
                throw new SSOException("Assertion failed : principals.size() == 1");
            }

            // 3. Find SSO User, authentication was successfull and we have only one principal
            // Check the username with the IdentityManager, just to be sure it's a valid user:
            Principal p =  (Principal) principals.iterator().next();
            im.userExists(p.getName());

            // 4. Create a new sso session :
            String ssoSessionId = sm.initiateSession(p.getName());
            SSOSession session = sm.getSession(ssoSessionId);

            notifyLoginSuccess(ctx, session.getUsername(), session, scheme);

            return session;

        } catch (AuthenticationFailureException e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage(), e);
            // Re-throw current exception ...
            notifyLoginFailed(ctx, cred, scheme, e);
            throw e;


        } catch (SSOAuthenticationException e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage(), e);
            // Re-throw current exception ...
            notifyLoginFailed(ctx, cred, scheme, e);
            throw e;

        } catch (SSOIdentityException e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage(), e);
            notifyLoginFailed(ctx, cred, scheme, e);
            throw new SSOException(e.getMessage() , e);

        } catch (SSOSessionException e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage(), e);
            notifyLoginFailed(ctx, cred, scheme, e);
            throw new SSOException(e.getMessage() , e);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            notifyLoginFailed(ctx, cred, scheme, e);
            throw new SSOException(e.getMessage() , e);

        }
    }

    public Credential newCredential(String schemeName, String name, Object value) throws SSOAuthenticationException {
        try {

            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            Authenticator au = domain.getAuthenticator();

            return au.newCredential(schemeName, name, value);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return null;
        }
    }

    public String getPrincipalName(String schemeName, Credential[] creds) throws SSOAuthenticationException {
        try {

            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            Authenticator au = domain.getAuthenticator();

            Principal p = au.getPrincipal(schemeName, creds);
            if (p != null)
                return p.getName();


        } catch (Exception e) {
            logger.error(e.getMessage(), e);

        }
        return null;
    }


    /**
     * Logouts a user from the SSO infrastructure.
     *
     * @param ctx the sso external context during method execution
     * @throws SSOException
     */
    public void logout(SSOContext ctx) throws SSOException {

        SSOSession session = ctx.getCurrentSession();
        if (session == null) return;

        String ssoSessionId = session.getId();

        try {

            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            SSOSessionManager sm = domain.getSessionManager();
            sm.invalidate(ssoSessionId);
            notifyLogoutSuccess(ctx);
        } catch (NoSuchSessionException e){
            // Ignore this ....
            if (logger.isDebugEnabled())
                logger.debug("[logout()] Session is not valid : " + ssoSessionId);

        } catch (SSOSessionException e) {
            logger.error(e.getMessage(), e);
            notifyLogoutFail(ctx, e);
            throw new SSOException (e.getMessage(), e);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            notifyLogoutFail(ctx, e);
            throw new SSOException (e.getMessage(), e);
        }
    }

    /**
     * Finds a user associated to the given session.
     *
     * @param sessionId
     *
     * @throws SSOException
     */
    public SSOUser findUserInSession(String sessionId)
            throws SSOException {
        try {

            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            SSOIdentityManager im = domain.getIdentityManager();
            return im.findUserInSession(sessionId);

        } catch (NoSuchSessionException e) {
            // Session is not valid ... (we could signal it with a specific exception)
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage(), e);

            throw new SSOException(e.getMessage(), e);

        } catch (SSOIdentityException e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage(), e);

            throw new SSOException(e.getMessage(), e);

        } catch (Exception e) {
            logger.error(e.getMessage(), e);

            throw new SSOException(e.getMessage(), e);
        }
    }

    public SSORole[] findRolesByUsername(String username) throws SSOException {
        try {
            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            SSOIdentityManager im = domain.getIdentityManager();
            return im.findRolesByUsername(username);

        } catch (SSOIdentityException e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage(), e);

            throw new SSOException(e.getMessage(), e);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new SSOException(e.getMessage(), e);
        }
    }

    public SSOSession findSession(String jossoSessionId) throws SSOException, NoSuchSessionException  {
        try {
            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            SSOSessionManager sm = domain.getSessionManager();
            return sm.getSession(jossoSessionId);
        } catch (NoSuchSessionException e) {
            throw e;
            
        } catch (SSOIdentityException e) {
            if (logger.isDebugEnabled())
                logger.debug(e.getMessage(), e);

            throw new SSOException(e.getMessage(), e);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new SSOException(e.getMessage(), e);
        }
    }

    protected void notifyLoginFailed(SSOContext ctx, Credential[] credentials, String scheme, Throwable error) {
        try {
            // We expect a spetial Event Manager ...
            SSOSecurityEventManager em = (SSOSecurityEventManager) Lookup.getInstance().lookupSecurityDomain().getEventManager();
            em.fireAuthenticationFailureEvent(ctx.getUserLocation(), scheme, credentials, error);

        } catch (Exception e) {
            logger.error("Can't notify login failure : " + e.getMessage(), e);
        }
    }

    protected void notifyLoginSuccess(SSOContext ctx, String username, SSOSession session, String scheme) {
        try {
            // We expect a spetial Event Manager ...
            SSOSecurityEventManager em = (SSOSecurityEventManager) Lookup.getInstance().lookupSecurityDomain().getEventManager();
            em.fireAuthenticationSuccessEvent(ctx.getUserLocation(), scheme, username, session.getId());

        } catch (Exception e) {
            logger.error("Can't notify login success : " + e.getMessage(), e);
        }
    }

    private void notifyLogoutFail(SSOContext ctx , Throwable error) {
        try {
            // We expect a spetial Event Manager ...
            SSOSecurityEventManager em = (SSOSecurityEventManager) Lookup.getInstance().lookupSecurityDomain().getEventManager();
            em.fireLogoutFailureEvent(ctx.getUserLocation(), ctx.getCurrentSession().getUsername(), ctx.getCurrentSession().getId(), error);

        } catch (Exception e) {
            logger.error("Can't notify login success : " + e.getMessage(), e);
        }
    }

    protected void notifyLogoutSuccess(SSOContext ctx) {
        try {
            // We expect a spetial Event Manager ...
            SSOSecurityEventManager em = (SSOSecurityEventManager) Lookup.getInstance().lookupSecurityDomain().getEventManager();
            em.fireLogoutSuccessEvent(ctx.getUserLocation() , ctx.getCurrentSession().getUsername(), ctx.getCurrentSession().getId());

        } catch (Exception e) {
            logger.error("Can't notify login success : " + e.getMessage(), e);
        }

    }


    /**
     * Initializes the SSO gateway.
     */
    public void initialize() {
        _initialized = true;
    }

    public boolean isInitialized() {
        return _initialized;
    }

    public void destroy() {
        _initialized = false;
    }


}
