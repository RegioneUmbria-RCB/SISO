/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.ComponentKeeper;
import org.josso.Lookup;
import org.josso.MBeanComponentKeeper;
import org.josso.gateway.session.service.ws.WebserviceSSOSessionManager;

/**
 * Service Locator for Gateway Services available as Webservices.
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: WebserviceGatewayServiceLocator.java,v 1.13 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class WebserviceGatewayServiceLocator extends GatewayServiceLocator {

    private static final Log logger = LogFactory.getLog(WebserviceGatewayServiceLocator.class);

    private static final String TRANSPORT_SECURITY_NONE = "none";
    private static final String TRANSPORT_SECURITY_CONFIDENTIAL = "confidential";

    private String _endpoint;
    private String _username;
    private String _transportSecurity = TRANSPORT_SECURITY_NONE;

    /**
     * Package private Constructor so that it can only be instantiated
     * by the GatewayServiceLocator Class.
     */
    public WebserviceGatewayServiceLocator() {
    }

    /**
     * Locates the SSO Session Manager Service Webservice implementation.
     *
     * @return the SSO session manager WS implementation.
     * @throws Exception
     */
    public org.josso.gateway.session.service.SSOSessionManager getSSOSessionManager() throws Exception {

        org.josso.gateway.session.service.ws.impl.SSOSessionManagerServiceLocator ssoManagerServiceLocator =
                new org.josso.gateway.session.service.ws.impl.SSOSessionManagerServiceLocator();
        org.josso.gateway.session.service.ws.impl.SSOSessionManager ssoSessionManagerWebservice;

        String smEndpoint = getEndpointBase() + "/josso/services/SSOSessionManager";

        logger.debug("Using SSOSessionManager endpoint '" + smEndpoint + "'");


        ssoManagerServiceLocator.setSSOSessionManagerEndpointAddress(smEndpoint);

        ssoSessionManagerWebservice = ssoManagerServiceLocator.getSSOSessionManager();

        WebserviceSSOSessionManager wsm = new WebserviceSSOSessionManager(ssoSessionManagerWebservice);

        ComponentKeeper ck = Lookup.getInstance().getComponentKeeper();
        if (ck instanceof MBeanComponentKeeper) {
            MBeanComponentKeeper mbeanCk = (MBeanComponentKeeper) ck;
            mbeanCk.registerResource(mbeanCk.buildObjectName(wsm, "WebserviceSSOSessionManager"), wsm);
        }

        return wsm;
    }

    /**
     * Locates the SSO Identity Manager Service Webservice implementation.
     *
     * @return the SSO session manager WS implementation.
     * @throws Exception
     */
    public org.josso.gateway.identity.service.SSOIdentityManager getSSOIdentityManager() throws Exception {
        org.josso.gateway.identity.service.ws.impl.SSOIdentityManagerServiceLocator ssoIdentityManagerServiceLocator =
                new org.josso.gateway.identity.service.ws.impl.SSOIdentityManagerServiceLocator();
        org.josso.gateway.identity.service.ws.impl.SSOIdentityManager ssoIdentityManagerWebservice;

        String imEndpoint = getEndpointBase() + "/josso/services/SSOIdentityManager";

        logger.debug("Using SSOIdentityManager endpoint '" + imEndpoint + "'");

        ssoIdentityManagerServiceLocator.setSSOIdentityManagerEndpointAddress(imEndpoint);

        ssoIdentityManagerWebservice = ssoIdentityManagerServiceLocator.getSSOIdentityManager();

        org.josso.gateway.identity.service.ws.WebserviceSSOIdentityManager wim = new org.josso.gateway.identity.service.ws.WebserviceSSOIdentityManager(ssoIdentityManagerWebservice);

        ComponentKeeper ck = Lookup.getInstance().getComponentKeeper();
        if (ck instanceof MBeanComponentKeeper) {
            MBeanComponentKeeper mbeanCk = (MBeanComponentKeeper) ck;
            mbeanCk.registerResource(mbeanCk.buildObjectName(wim, "WebserviceSSOIdentityManager"), wim);
        }


        return wim;
    }

    /**
     * Builds the endpoint base string.
     *
     * @return the endpoint base
     */
    private String getEndpointBase() {
        return (_transportSecurity.equalsIgnoreCase(TRANSPORT_SECURITY_CONFIDENTIAL) ? "https" : "http") +
                "://" + _endpoint;

    }

    //----------------------------------------------------------------- Configuration Properties

    /**
     * SOAP end point, e.g. localhost:8080
     */
    public void setEndpoint(String endpoint) {
        _endpoint = endpoint;
    }

    /**
     * SOAP end point, e.g. localhost:8080
     */
    public String getEndpoint() {
        return _endpoint;
    }

    /**
     * Set the username used to authenticate SOAP messages.
     *
     * @param username the username used to authenticate the SOAP message.
     */
    public void setUsername(String username) {
        WebserviceClientAuthentication.setUsername(username);
        _username = username;
    }

    /**
     * Getter for username used to authenticate SOAP messages.
     */
    public String getUsername() {
        return _username;
    }

    /**
     * Set the password used to authenticate SOAP messages.
     *
     * @param password the password used to authenticate the SOAP message.
     */
    public void setPassword(String password) {
        WebserviceClientAuthentication.setPassword(password);
    }

    public String getPassword() {
        return "*";
    }

    /**
     * Transport security used in SOAP messages, valid values are : none, confidential 
     * @param transportSecurity valid values are none, confidential
     */
    public void setTransportSecurity(String transportSecurity) {
        _transportSecurity = transportSecurity;
    }

    /**
     * Transport security used in SOAP messages, valid values are : none|confidential
     */
    public String getTransportSecurity() {
        return _transportSecurity;
    }

}
