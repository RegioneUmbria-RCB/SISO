/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.auth.scheme;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.auth.BindableCredentialStore;
import org.josso.auth.CredentialStore;
import org.josso.auth.exceptions.SSOAuthenticationException;
/**
 * Basic authentication scheme, supporting username and password credentials.
 * <p/>
 * <p>
 * This implementation relays on the configured CredentialStore to authenticate users.
 * The configured store must be instance of BindableCredentialStore. If the bind operation provided by the store succeeds,
 * the user is authenticated.
 * </p>
 *
 * @see org.josso.auth.CredentialStore
 * @see org.josso.auth.BindableCredentialStore
 * @see org.josso.gateway.identity.service.store.AbstractStore
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: BindUsernamePasswordAuthScheme.java,v 1.3 2006/03/16 21:11:57 sgonzalez Exp $
 *
 */

public class BindUsernamePasswordAuthScheme extends UsernamePasswordAuthScheme {

    private static final Log logger = LogFactory.getLog(BindUsernamePasswordAuthScheme.class);

    /**
     * Authenticates the user using recieved credentials to proof his identity.
     *
     * @return the Principal if credentials are valid, null otherwise.
     */
    public boolean authenticate() throws SSOAuthenticationException {

        setAuthenticated(false);

        String username = getUsername(_inputCredentials);
        String password = getPassword(_inputCredentials);

        // Check if all credentials are present.
        if (username == null || username.length() == 0 ||
                password == null || password.length() == 0) {

            if (logger.isDebugEnabled()) {
                logger.debug("Username " + (username == null || username.length() == 0 ? " not" : "") + " provided. " +
                             "Password " + (password == null || password.length() == 0 ? " not" : "") + " provided.");
            }

            // We don't support empty values !
            return false;
        }

        // Authenticate the user against the configured store via a bind
        // The configured store could be using a LDAP server , a DB, etc.
        if (((BindableCredentialStore)_credentialStore).bind(username, password)) {

            if (logger.isDebugEnabled())
                logger.debug("[authenticate()], Principal authenticated : " + username);

            // We have successfully authenticated this user.
            setAuthenticated(true);
            return true;
        }

        return false;
    }

    public void setCredentialStore(CredentialStore c) {
        if (c instanceof BindableCredentialStore) {
            super.setCredentialStore(c);
        } else {
            throw new RuntimeException("Invalid credential store type, it must be instace of " + BindableCredentialStore.class.getName());
        }

    }

}
