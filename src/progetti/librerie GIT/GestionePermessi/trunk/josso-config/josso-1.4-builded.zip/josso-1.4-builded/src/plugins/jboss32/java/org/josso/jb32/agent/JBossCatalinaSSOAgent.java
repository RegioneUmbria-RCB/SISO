/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */

package org.josso.jb32.agent;

import org.apache.catalina.Context;
import org.josso.agent.SSOAgentRequest;
import org.josso.agent.SingleSignOnEntry;
import org.josso.tc50.agent.CatalinaSSOAgent;
import org.josso.tc50.agent.CatalinaSSOAgentRequest;

/**
 * JBoss Agent implementation.
 * On each processRequest() call it does two things :
 *
 * <p>
 * 1. Replaces the partner web application context's realm with our JBossCatalinaRealm.
 * <p>
 * 2. Associates the Active Subject information to the current thread so that partner web
 *    applications can have an authenticated http request.
 * <p>
 * The JBossCatalinaSSOAgent must be used only in JBoss by configuring the agent configuration
 * file in the following way :
 *
<pre>
&lt;agent&gt;
  &lt;class&gt;org.josso.agent.JBossCatalinaSSOAgent&lt;/class&gt;
     ...
&lt;/agent&gt;
</pre>
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: JBossCatalinaSSOAgent.java,v 1.3 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class JBossCatalinaSSOAgent extends CatalinaSSOAgent {

    public SingleSignOnEntry processRequest(SSOAgentRequest request) {
        CatalinaSSOAgentRequest r = (CatalinaSSOAgentRequest) request;
        Context c = r.getContext();


        if (debug > 0)
            log("Executing authenticate for jboss");

        // In JBoss this will allow the JBoss Security Manager (JaasSecurityManager) to
        // associate the authenticated Subject to the current Thread.
        // This is needed so that when the Security Manager gets called by Catalina it
        // will have which is the Subject for performing authorization procedures like
        // isUserInRole().
        // Since the JBoss Security Manager has a cache with all the authenticated Principals,
        // it won't invoke the JAAS login module each time, avoiding a performance impact.
        authenticate(request);

        return super.processRequest(request);
    }
}
