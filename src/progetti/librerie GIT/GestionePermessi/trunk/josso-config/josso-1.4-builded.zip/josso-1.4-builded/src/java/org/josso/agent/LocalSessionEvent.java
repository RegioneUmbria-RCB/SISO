/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.agent;

import java.util.EventObject;

/**
 * General event for notifying listeners of significant changes on a LocalSession.
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: LocalSessionEvent.java,v 1.4 2006/02/09 16:53:05 sgonzalez Exp $
 */
public class LocalSessionEvent
    extends EventObject {

    /**
     * The event _data associated with this event.
     */
    private Object _data = null;

    /**
     * The Session on which this event occurred.
     */
    private LocalSession _localSession = null;

    /**
     * The event _type this instance represents.
     */
    private String _type = null;

    /**
     * Construct a new SessionEvent with the specified parameters.
     *
     * @param localSession Local Session on which this event occurred
     * @param type Event _type
     * @param data Event _data
     */
    public LocalSessionEvent(LocalSession localSession, String type, Object data) {
        super(localSession);
        this._localSession = localSession;
        this._type = type;
        this._data = data;
    }

    /**
     * Return the event _data of this event.
     */
    public Object getData() {
        return (this._data);
    }

    /**
     * Return the Session on which this event occurred.
     */
    public LocalSession getLocalSession() {
        return (this._localSession);
    }

    /**
     * Return the event _type of this event.
     */
    public String getType() {
        return (this._type);
    }

    /**
     * Return a string representation of this event.
     */
    public String toString() {
        return ("LocalSessionEvent['" + getLocalSession() + "','" +
                getType() + "']");
    }

}
