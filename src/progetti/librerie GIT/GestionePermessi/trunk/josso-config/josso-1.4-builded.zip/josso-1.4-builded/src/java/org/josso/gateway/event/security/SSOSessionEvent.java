/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.event.security;


import org.josso.gateway.event.BaseSSOEvent;

/**
 * Event for notifying chages releated to an SSO Session.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOSessionEvent.java,v 1.3 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class SSOSessionEvent extends BaseSSOEvent {

    /**
     * The data associated with this event.
     */
    private Object data = null;

    private String username;

    /**
     * Construct a new SessionEvent
     *
     * @param sessionId SSO Session identifier on which this event occurred
     * @param type
     * @param data
     */
    public SSOSessionEvent(String username, String sessionId, String type, Object data) {
        super(type, sessionId);
        this.data = data;
        this.username = username;
    }

    public SSOSessionEvent(String username, String sessionId, String type, Throwable error) {
        super(type, sessionId, error);
        this.username = username;
    }


    /**
     * Return the event this._data of this event.
     */
    public Object getData() {
        return (this.data);
    }

    /**
     * Return the Session on which this event occurred.
     */
    public String getSessionId() {
        return (String) getSource();
    }

    /**
     * Returns the username associated to this event.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Return a string representation of this event.
     */
    public String toString() {
        return ("SSOSessionEvent['" + getSessionId() + "','" +
                getType() + "']");
    }

}


