/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.audit.service;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.Lookup;
import org.josso.gateway.audit.SSOAuditManager;
import org.josso.gateway.audit.SSOAuditTrail;
import org.josso.gateway.audit.exceptions.SSOAuditException;
import org.josso.gateway.audit.service.handler.SSOAuditTrailHandler;
import org.josso.gateway.event.BaseSSOEvent;
import org.josso.gateway.event.SSOEvent;
import org.josso.gateway.event.SSOEventListener;
import org.josso.gateway.event.security.SSOIdentityEvent;
import org.josso.gateway.event.security.SSOSessionEvent;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

/**
 * This implementation logs all events using the standard logger.
 * The logger category is this implementation FQCN.
 *
 * Enalbe/Disable audit audit using your logger configuration.
 * Messages are logged with INFO priority.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOAuditManagerImpl.java,v 1.5 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class SSOAuditManagerImpl implements SSOAuditManager, SSOEventListener {

    private static final Log logger = LogFactory.getLog(SSOAuditManagerImpl.class);

    public static final String OUTCOME_SUCCESS = "success";

    public static final String OUTCOME_FAILURE = "failure";

    private String name;

    // List of SSOAuditTrailHandlers ...
    private List handlers;

    public SSOAuditManagerImpl () {
        handlers = new ArrayList();
        this.name = "SSOAuditManagerImpl";
    }

    public String getName() {
        return name;
    }

    public void initialize() {
        // Lookup for Event Manager and register this manager as a listener :
        try {
            Lookup.getInstance().lookupSecurityDomain().getEventManager().registerListener(this);
        } catch (Exception e) {
            logger.error("Can't get register SSOAuditManager as event listener : " + e.getMessage(), e);
        }
    }

    public void destroy() {

    }

    public void addHandler(SSOAuditTrailHandler handler) {
        logger.info("Adding handler : " + handler.getClass().getName());
        handlers.add(handler);
    }

    /**
     * Receives SSO events to generate audit trails.
     */
    public void handleSSOEvent(SSOEvent event) {
        try {
            SSOAuditTrail auditTrail = buildAuditTrail(event);
            processAuditTrail(auditTrail);
        } catch (Exception e) {
            logger.error("Can't generate audit : " + e.getMessage(), e);
        }

    }


    /**
     * This implementation just logs the received trail using this audit manager's logger.
     * Subclasses may provide more complex functionallity.
     */
    public void processAuditTrail(SSOAuditTrail trail) throws SSOAuditException {

        for (int i = 0; i < handlers.size(); i++) {
            SSOAuditTrailHandler handler = (SSOAuditTrailHandler) handlers.get(i);

            if (handler.handle(trail) == SSOAuditTrailHandler.CONTINUE_PROCESS) {
                if (logger.isDebugEnabled())
                    logger.debug("Process interrupted by : " + handler);
                break;
            }
        }

    }

    /**
     * This method builds a SSOAuditTrail based on a SSEvent instance.
     */
    protected SSOAuditTrail buildAuditTrail(SSOEvent event) {

        String category = null;
        String severity = "info";
        String subject = null;
        String outcome = null;
        Throwable error = null;

        // General SSOEvent handling
        Date time = new Date();
        String action = event.getType();

        if (event instanceof BaseSSOEvent) {

            error = ((BaseSSOEvent)event).getError();
            outcome = error != null ? OUTCOME_FAILURE : OUTCOME_SUCCESS;
        }

        Properties props = new Properties();

        // Build detailed informaton based on a SSOIdentityEvent
        if (event instanceof SSOIdentityEvent) {

            category = "sso-user";

            SSOIdentityEvent ie = (SSOIdentityEvent) event;
            subject = ((SSOIdentityEvent)event).getUsername();

            // Add other properties :

            props.setProperty("remoteHost", ie.getRemoteHost());

            if (ie.getScheme() != null)
                props.setProperty("authScheme", ie.getScheme());

            if (ie.getSessionId() != null)
                props.setProperty("ssoSessionId", ie.getSessionId());

        // Build detailed informaton based on a SSOSessionEvent
        } else if (event instanceof SSOSessionEvent) {

            category = "sso-session";



            SSOSessionEvent se = (SSOSessionEvent) event;
            subject = se.getUsername();

            props.setProperty("ssoSessionId", se.getSessionId());

            if (se.getData() != null)
                props.setProperty("data", se.getData().toString());

        }

        // Return the new SSOAuditTrailInstance ...
        return new BaseSSOAuditTrail(category, severity, subject, action, outcome, time, props, error);

    }

}
