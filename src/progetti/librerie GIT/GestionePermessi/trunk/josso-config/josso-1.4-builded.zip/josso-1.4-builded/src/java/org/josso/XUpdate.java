/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso;


import org.w3c.dom.Node;
import org.xmldb.common.xml.queries.XUpdateQuery;
import org.xmldb.xupdate.lexus.XUpdateQueryImpl;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

/**
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: XUpdate.java,v 1.3 2006/02/09 16:53:05 sgonzalez Exp $
 */

public class XUpdate {


    /**
     * Main-method. You can manually test your update operations.
     */
    public static void main(String args[]) throws Exception {
        if (args.length == 0) {
            System.err.println("usage: java org.xmldb.xupdate.lexus.XUpdateQueryImpl update document");
            System.err.println("       update   - filename of the file which contains XUpdate operations");
            System.err.println("       document - filename of the file which contains the content to update");
            System.exit(0);
        }

        // parse the update file
        File file = new File(args[0]);
        BufferedReader br = new BufferedReader(new FileReader(file));
        char[] characters = new char[new Long(file.length()).intValue()];
        br.read(characters, 0, new Long(file.length()).intValue());
        String queryStr = new String(characters);

        // parse the document file
        Node myDocument = null;
        DocumentBuilderFactory parserFactory = DocumentBuilderFactory.newInstance();

        parserFactory.setValidating(false);
        parserFactory.setNamespaceAware(true);
        parserFactory.setIgnoringElementContentWhitespace(true);

        DocumentBuilder builder = parserFactory.newDocumentBuilder();
        myDocument = builder.parse(args[1]);

        System.setProperty("org.xmldb.common.xml.queries.XPathQueryFactory",
                         "org.xmldb.common.xml.queries.xalan2.XPathQueryFactoryImpl");
        // update the document and print time used for the updates
        XUpdateQuery xq = new XUpdateQueryImpl();

        System.err.println("Starting updates...");
        long timeStart = System.currentTimeMillis();

        xq.setQString(queryStr);
        xq.execute(myDocument);

        File out = new File("data-mod.xml");
        Result result = new StreamResult(out);

        // Write the DOM document to the file
        Source source = new DOMSource(myDocument);
        Transformer xformer = TransformerFactory.newInstance().newTransformer();
        xformer.transform(source, result);

        long timeEnd = System.currentTimeMillis();
        System.err.println("Updates done in " + (timeEnd - timeStart) + " ms ...");
    }
}
