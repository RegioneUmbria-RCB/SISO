/**
 * SSOEventManagerClientService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jul 21, 2005 (10:26:06 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.event.client.ws.impl;

public interface SSOEventManagerClientService extends javax.xml.rpc.Service {
    public java.lang.String getSSOEventManagerClientAddress();

    public org.josso.gateway.event.client.ws.impl.SSOEventManagerClient getSSOEventManagerClient() throws javax.xml.rpc.ServiceException;

    public org.josso.gateway.event.client.ws.impl.SSOEventManagerClient getSSOEventManagerClient(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
