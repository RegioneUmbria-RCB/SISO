/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.util.config;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;
import org.xmldb.common.xml.queries.XUpdateQuery;
import org.xmldb.xupdate.lexus.XUpdateQueryImpl;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * This is a base configuration handler that uses XUpdate to add, update and remove elements from a XML files.
 * The XML file to be updated is referred by the ConfigurationContext instance related to this handler.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: XUpdateConfigurationHandler.java,v 1.6 2006/03/28 22:05:42 sgonzalez Exp $
 */
public class XUpdateConfigurationHandler implements ConfigurationHandler {

    // log4j logger instance.
    private static final Log logger = LogFactory.getLog(XUpdateConfigurationHandler.class);

    private static final DateFormat df = new SimpleDateFormat("yyyy-MM-dd_HH_mm_ss_SSS");

    // The configuration context related to the handler.
    private ConfigurationContext _ctx;

    /**
     * XUPDATE constant used to begin all queries.
     */
    public static final String XUPDATE_START ="<xupdate:modifications version=\"1.0\"\n" +
                                              "       xmlns:xupdate=\"http://www.xmldb.org/xupdate\">\n";

    /**
     * XUPDATE constant used to end all queries.
     */
    public static final String XUPDATE_END =  "\n</xupdate:modifications> ";

    /**
     * XPath expression to find where existing elements are found in the document.
     */
    private String elementsBaseLocation;

    /**
     * XPath expression to find where new elements will be inserted AFTER in the document (as siblings)
     */
    private String newElementsBaseLocation;

    /**
     * @param ctx                       The configuration context used by this handler.
     * @param elementsBaseLocation      XPath expression to find where existing elements are found in the document.
     * @param newElementsBaseLocation   XPath expression to find where new elements will be inserted AFTER in the document (as siblings)
     */
    public XUpdateConfigurationHandler(ConfigurationContext ctx, String elementsBaseLocation, String newElementsBaseLocation) {
        this(elementsBaseLocation, newElementsBaseLocation);
        _ctx = ctx;
    }

    /**
     * @param elementsBaseLocation      XPath expression to find where existing elements are found in the document.
     * @param newElementsBaseLocation   XPath expression to find where new elements will be inserted AFTER in the document (as siblings)
     */
    public XUpdateConfigurationHandler(String elementsBaseLocation, String newElementsBaseLocation) {
        // Setup XUpdate factory.
        System.setProperty("org.xmldb.common.xml.queries.XPathQueryFactory",
                           "org.xmldb.common.xml.queries.xalan2.XPathQueryFactoryImpl");

        this.elementsBaseLocation = elementsBaseLocation;
        this.newElementsBaseLocation = newElementsBaseLocation;
    }

    /**
     * Setter for this handler configuration context.
     */
    public void setSSOConfigurationContext(ConfigurationContext ctx) {
        _ctx = ctx;
    }

    /**
     * Getter for this handler configuration context.
     */
    public ConfigurationContext getSSOConfigurationContext() {
        return _ctx;
    }

    /**
     * This method will add/update the specified element based on it's old and new values.
     * If the oldValue is null, this method will insert the element, if it's not, it will try to update an existing element.
     *
     * @param element
     * @param oldValue
     * @param newValue
     */
    public void saveElement(String element, String oldValue, String newValue) {

        if (!_ctx.isConfigurationUpdatable())
            return;

        // Log what we're doing ....
        if (logger.isDebugEnabled()) {
            logger.debug("saveElement : " + element + " ["+oldValue+"/"+newValue+"] at " +
                         this.elementsBaseLocation + " " + this.newElementsBaseLocation);
        }

        try {
            // Update an element in a josso configuration file :
            String qry;
            if (oldValue == null) {
                // The attribute is null, add a new element.
                qry = buildXInsertAfterElementQueryString(this.newElementsBaseLocation, element, unicodeEscape(newValue));
            } else {
                // The attribute has a value, update the existing element.
                qry = buildXUPdateElementQueryString(this.elementsBaseLocation + "/" + element, unicodeEscape(newValue));
            }
            this.updateConfiguration(qry);
        } catch (Exception e) {
            logger.error("Can't update configuration element for : " + element + ", new value : " + newValue+ " :\n" + e.getMessage(), e);
        }
    }

    /**
     * This method will remove the specified element. If the configuration is not updatable, this method does nothing.
     *
     * @see ConfigurationContext#isConfigurationUpdatable()
     */
    public void removeElement(String element) {
        try {

            if (!_ctx.isConfigurationUpdatable())
                return;

            // Log what we're doing ....
            if (logger.isDebugEnabled()) {
                logger.debug("removeElement : " + element + " at " + this.elementsBaseLocation);
            }

            // Delete an element from the configuration file :
            String qry = buildXDeleteElementQuery(this.elementsBaseLocation, element);
            this.updateConfiguration(qry);

        } catch (Exception e) {
            logger.error("Can't update configuration element for : " + element + " :\n" + e.getMessage(), e);
        }
    }


    /**
     * Updates the element located after the xpathExpr.  If the configuration is not updatable, the method does nothing.
     * It checks that configuration backup is enable.
     *
     * @param qry the XUpdate query to be used to update the configuration file.
     *
     * @see ConfigurationContext#isConfigurationUpdatable()
     * @see ConfigurationContext#isBackupEnabled()
     */
    protected void updateConfiguration(String qry) throws Exception {

        if (!_ctx.isConfigurationUpdatable())
            return;

        // Read the configuration file.
        Node jossoCfgDocument = readConfigFile();

        // Assume any exception is due to a "no nodes selected" problem ...!?
        XUpdateQuery xq = new XUpdateQueryImpl();
        xq.setQString(qry);

        xq.execute(jossoCfgDocument);

        writeConfigFile(jossoCfgDocument);

    }

    /**
     * This method reads a configuration into a DOM tree.  The file is retrieved from the ConfigurationContext instance.
     *
     * @return the DOM tree representing the configuration file.
     */
    protected Node readConfigFile()
            throws ParserConfigurationException, IOException, SAXException {

        // parse the document file
        Node myDocument;
        DocumentBuilderFactory parserFactory = DocumentBuilderFactory.newInstance();

        parserFactory.setValidating(false);
        parserFactory.setNamespaceAware(true);
        parserFactory.setIgnoringElementContentWhitespace(true);

        File file = _ctx.getConfigurationFile();

        if (!file.exists())
            throw new IOException("File not found" + file.getAbsolutePath());

        DocumentBuilder builder = parserFactory.newDocumentBuilder();
        myDocument = builder.parse(file);

        return myDocument;

    }

    /**
     * Makes a backup of the configuration file to disk.
     */
    protected void backupConfigFile() throws Exception {

        String timestamp = df.format(new Date());

        FileInputStream fis = null;
        FileOutputStream fos = null;
        try {
            fis = new FileInputStream(_ctx.getConfigurationFile());
            fos = new FileOutputStream(_ctx.getConfigurationFile().getAbsolutePath() + "." + timestamp + ".bkp");
            // Copy the file ...
            byte[] buf = new byte[1024];
            int i;
            while((i=fis.read(buf))!=-1) {
              fos.write(buf, 0, i);
              }

        } catch (Exception e) {
            logger.error("Can't backup configuration file : " + _ctx.getConfigurationFile().getName() + " : " +
                        e.getMessage() != null ? e.getMessage() : e.toString());
            throw e;

        } finally {

            try { if (fis != null)fis.close();} catch (Exception e) { /**/ }
            try { if (fos != null)fos.close();} catch (Exception e) { /**/ }
        }

    }

    /**
     * Save this file to disk
     */
    protected void writeConfigFile(Node document) throws Exception {
        writeConfigFile(document, _ctx.getConfigurationFile());
    }

    /**
     * Save this file to disk
     */
    protected void writeConfigFile(Node document, File file) throws Exception {

        // Backup configuration file.
        if (_ctx.isBackupEnabled())
            backupConfigFile();

        // Write the DOM document to the file
        java.io.FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(file, false);
            Result result = new StreamResult(fos);
            Source source = new DOMSource(document);
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            xformer.transform(source, result);
        } catch (java.io.IOException e) {
            logger.error(e, e);
        } finally {
            if (fos != null) try { fos.close(); } catch (java.io.IOException e) { /**/ }
        }

    }

    // Utils to build different type of queries :

    /**
     * Builds an XUpdate query string to update an element's value.
     *
     * @param xpathExpr the XPath expression to locate the element.
     * @param newValue the new element value, must be already escaped.
     */
    protected String buildXUPdateElementQueryString(String xpathExpr, String newValue) {
        // Build a new XUPDATE expression :
        String qry =
                XUPDATE_START +
                "\t<xupdate:update select=\"" + xpathExpr + "\">" + newValue + "</xupdate:update>" +
                XUPDATE_END;

        if (logger.isDebugEnabled())
            logger.debug("buildXUPdateElementQueryString("+xpathExpr+","+newValue+") = \n" + qry);

        return qry ;
    }

    /**
     * Builds a XUpdate query string to append a new element to the document.
     *
     * @param xpathExpr the XPath expression to locate the element where the new element will be appended.
     * @param element the new element name
     * @param value new element value, must be already escaped.
     */
     protected String buildXAppendElementQueryString(String xpathExpr, String element, String value) {
        String qry =
                XUPDATE_START +
                "\t<xupdate:append select=\""+ xpathExpr+ "\" >\n" +
                "\t\t<xupdate:element name=\""+element+"\">"+value+"</xupdate:element>\n" +
                "\t</xupdate:append>" +
                XUPDATE_END;

        if (logger.isDebugEnabled())
            logger.debug("buildXAppendElementQueryString("+xpathExpr+","+element+","+value+") = \n" + qry);

        return qry ;


    }

    /**
     * Builds a XUpdate query string to insert an element after another.
     *
     * @param xpathExpr the XPath expression to locate the element where the new element will be inserted.
     * @param element the new element name
     * @param value new element value, must be already escaped.
     */
     protected String buildXInsertAfterElementQueryString(String xpathExpr, String element, String value) {
        String qry =
                XUPDATE_START +
                "\t<xupdate:insert-after select=\""+ xpathExpr+ "\" >\n" +
                "\t\t<xupdate:element name=\""+element+"\">"+value+"</xupdate:element>\n" +
                "\t</xupdate:insert-after>" +
                XUPDATE_END;

        if (logger.isDebugEnabled())
            logger.debug("buildXAppendElementQueryString("+xpathExpr+","+element+","+value+") = \n" + qry);

        return qry ;

    }

    /**
     * Builds a XUpdate query string to append a new element with the specified XML as body.
     * @param xpathExpr
     * @param element
     * @param xml
     */
    protected String buildXAppendElementXMLQueryString(String xpathExpr, String element, String xml) {
        String qry =
                XUPDATE_START +
                "\t<xupdate:append select=\""+ xpathExpr + "\" >\n" +
                "\t\t<xupdate:element name=\"" + element+ "\">\n" +
                xml + "\n" +
                "\t\t</xupdate:element>\n" +
                "\t</xupdate:append>"+
                XUPDATE_END;

        if (logger.isDebugEnabled())
            logger.debug("buildXInsertXMLQueryString("+xpathExpr+","+element+","+xml+") = \n" + qry);

        return qry ;
    }

    /**
     * Builds a XUpdate query string to delete the specified element.
     *
     * @param xpathExpr
     * @param element
     */
    protected String buildXDeleteElementQuery(String xpathExpr, String element) {
        String qry =
                XUPDATE_START +
                "\t<xupdate:remove select=\""+xpathExpr + "/" + element +"\"/>" +
                XUPDATE_END;

        if (logger.isDebugEnabled())
            logger.debug("buildXDeleteElementQuery("+xpathExpr+","+element+") = \n" + qry);

        return qry ;
    }


    protected String getElementsBaseLocation() {
        return elementsBaseLocation;
    }

    protected String getNewElementsBaseLocation() {
        return newElementsBaseLocation;
    }


    /**
     * This will scape all spetial chars like <, >, &, \, " and unicode chars.
     */
    public String unicodeEscape(String v)  {

      StringWriter w = new StringWriter();

      int len = v.length();
      for (int j = 0;  j < len;  j++) {
        char c = v.charAt(j);
        switch (c) {
          case '&':  w.write("&amp;");  break;
          case '<':  w.write("&lt;");   break;
          case '>':  w.write("&gt;");   break;
          case '\'': w.write("&apos;"); break;
          case '"':  w.write("&quot;"); break;
          default:
            if (canEncode(c)) {
              w.write(c);
            } else {
              w.write("&#");
              w.write(Integer.toString(c));
              w.write(';');
            }
            break;
        }
      }
        ByteArrayInputStream d;
        return w.toString();
    }

    public static boolean canEncode(char c) {
      return c < 127;
    }


}
