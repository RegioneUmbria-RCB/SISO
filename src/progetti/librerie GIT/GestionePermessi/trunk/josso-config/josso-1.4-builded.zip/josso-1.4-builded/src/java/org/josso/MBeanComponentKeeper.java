/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso;


import org.apache.commons.configuration.Configuration;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.modeler.Registry;
import org.josso.agent.SSOAgent;
import org.josso.agent.SSOAgentConfigurationEventHandler;
import org.josso.agent.SSOAgentInfo;
import org.josso.auth.Authenticator;
import org.josso.auth.CredentialStore;
import org.josso.auth.scheme.AuthenticationScheme;
import org.josso.gateway.GatewayServiceLocator;
import org.josso.gateway.SSOGatewayInfo;
import org.josso.gateway.audit.SSOAuditManager;
import org.josso.gateway.audit.service.handler.SSOAuditTrailHandler;
import org.josso.gateway.event.SSOEventListener;
import org.josso.gateway.event.SSOEventManager;
import org.josso.gateway.identity.service.SSOIdentityManager;
import org.josso.gateway.identity.service.store.IdentityStore;
import org.josso.gateway.session.service.SSOSessionManager;
import org.josso.gateway.session.service.SessionIdGenerator;
import org.josso.gateway.session.service.store.SessionStore;
import org.josso.util.config.SSOConfigurationEventHandler;

import javax.management.*;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * This ComponentKeeper will register a Model MBean for using JOSSO components as managed resources.
 * It can also keep JOSSO configuration files synchronized with MBeans attribute changes.
 * 
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 *
 * @version $Id: MBeanComponentKeeper.java,v 1.8 2006/02/16 22:29:20 sgonzalez Exp $
 */
public class MBeanComponentKeeper extends ComponentKeeperImpl implements NotificationListener {

    private static final Log logger = LogFactory.getLog(MBeanComponentKeeper.class);

    /**
     * Base JOSSO JMX domain.
     */
    public static final String JOSSO_DOMAIN = "josso";

    /**
     * Common Modelere MBean registry
     */
    private Registry _registry;

    private List _eventListeners;

    public MBeanComponentKeeper() {
        super();
        _registry = Registry.getRegistry(null, null);
        _eventListeners = new ArrayList();
    }

    // ---------------------------------------------------------------------------------

    /**
     * JMX NotificationListener implementation.
     */
    public void handleNotification(Notification notification, Object o) {

        if (logger.isDebugEnabled())
            logger.debug("Received notification  : " + notification.getType());

        try {
            String eventType = notification.getType();

            // Submit this to all the chain of listeners.
            for (int i = 0; i < _eventListeners.size(); i++) {
                SSOConfigurationEventListener listener = (SSOConfigurationEventListener) _eventListeners.get(i);
                if (listener.isEventEnabled(eventType, notification))
                    listener.handleEvent(eventType, notification);
            }

        } catch (Exception e) {
            logger.error("Can't handle notification " + notification + ": \n" + e.getMessage(), e);
        }

    }

    // ---------------------------------------------------------------------------------

    public SecurityDomain fetchSecurityDomain() throws Exception {
        SecurityDomain  domain = super.fetchSecurityDomain();

        SSOGatewayInfo info = new SSOGatewayInfo(domain);
        ObjectName oname = buildObjectName("type=SSOGatewayInfo");
        registerResource(oname, info);

        return domain;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected SSOSessionManager fetchSessionManager(Configuration config) throws Exception {
        SSOSessionManager sm = super.fetchSessionManager(config);
        ObjectName oname = buildObjectName(sm, "SSOSessionManager");
        registerResource(oname, sm);
        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(super.getSSOGatewayConfigurationContext(),
                                                                "/domain/sso-session-manager",
                                                                "/domain/sso-session-manager/class",
                                                                oname,
                                                                new String[0]));

        return sm;

    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected SessionIdGenerator fetchSessionIdGenerator(Configuration config) throws Exception {
        SessionIdGenerator sig = super.fetchSessionIdGenerator(config);
        ObjectName oname = buildObjectName(sig, "SessionIdGenerator");
        registerResource(oname, sig);
        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                "/domain/sso-session-manager/sso-session-id-generator",
                                                                "/domain/sso-session-manager/sso-session-id-generator/class",
                                                                oname,
                                                                new String[0]));

        return sig;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected SessionStore fetchSessionStore(Configuration config) throws Exception {
        SessionStore ss = super.fetchSessionStore(config);
        ObjectName oname = buildObjectName(ss, "SessionStore");
        registerResource(oname, ss);

        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                "/domain/sso-session-manager/sso-session-store",
                                                                "/domain/sso-session-manager/sso-session-store/class",
                                                                oname,
                                                                new String[0]));

        return ss;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected Authenticator fetchAuthenticator(Configuration config) throws Exception {
        Authenticator a = super.fetchAuthenticator(config);
        ObjectName oname = buildObjectName(a, "Authenticator");
        registerResource(oname, a);
        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                "/domain/authenticator",
                                                                "/domain/authenticator/class",
                                                                oname,
                                                                new String[0]));
        return a;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected AuthenticationScheme fetchAuthenticationScheme(Configuration config) throws Exception {

        AuthenticationScheme a = super.fetchAuthenticationScheme(config);

        ObjectName oname = buildObjectName(a, "AuthenticationScheme");
        registerResource(oname, a);
        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                "/domain/authenticator/authentication-schemes/authentication-scheme[name='"+a.getName()+"']",
                                                                "/domain/authenticator/authentication-schemes/authentication-scheme[name='"+a.getName()+"']/class",
                                                                oname,
                                                                new String[0]));
        return a;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected CredentialStore fetchCredentialStore(Configuration config) throws Exception {
        CredentialStore cs = super.fetchCredentialStore(config);
        AuthenticationScheme as = (AuthenticationScheme) _cfg.peek();
        ObjectName oname = buildObjectName("type=CredentialStore,auth="+as.getName());
        registerResource(oname,cs);
        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                "/domain/authenticator/authentication-schemes/authentication-scheme[name='"+as.getName()+"']/credential-store",
                                                                "/domain/authenticator/authentication-schemes/authentication-scheme[name='"+as.getName()+"']/credential-store/class",
                                                                oname,
                                                                new String[0]));
        return cs;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected SSOIdentityManager fetchIdentityManager(Configuration config) throws Exception {
        SSOIdentityManager im = super.fetchIdentityManager(config);
        ObjectName oname = buildObjectName(im, "SSOIdentityManager");
        registerResource(oname, im);
        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                "/domain/sso-identity-manager",
                                                                "/domain/sso-identity-manager/class",
                                                                oname,
                                                                new String[0]));
        return im;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected IdentityStore fetchIdentityStore(Configuration config) throws Exception {
        IdentityStore is = super.fetchIdentityStore(config);
        ObjectName oname = buildObjectName(is, "IdentityStore");
        registerResource(oname, is);
        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                "/domain/sso-identity-manager/sso-identity-store",
                                                                "/domain/sso-identity-manager/sso-identity-store/class",
                                                                oname,
                                                                new String[0]));
        return is;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected SSOAuditManager fetchAuditManager(Configuration config) throws Exception {
        SSOAuditManager am = super.fetchAuditManager(config);
        ObjectName oname = buildObjectName(am, "SSOAuditManager");
        registerResource(oname, am);
        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                "/domain/sso-audit-manager",
                                                                "/domain/sso-audit-manager/class",
                                                                oname,
                                                                new String[0]));
        return am;
    }

    protected List fetchAuditHandlers(Configuration config) throws Exception {
        List handlers = super.fetchAuditHandlers(config);

        for (int i = 0; i < handlers.size(); i++) {
            SSOAuditTrailHandler handler = (SSOAuditTrailHandler) handlers.get(i);

            ObjectName oname = buildObjectName(handler, "SSOAuditTrailHandler");
            registerResource(oname, handler);
            this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                    "/domain/sso-audit-manager/handlers/handler[name='"+handler.getName()+"']",
                                                                    "/domain/sso-audit-manager/handlers/handler[name='"+handler.getName()+"']/class",
                                                                    oname,
                                                                    new String[0]));

        }

        return handlers;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected SSOEventManager fetchEventManager(Configuration config) throws Exception {
        SSOEventManager em = super.fetchEventManager(config);
        ObjectName oname = buildObjectName(em, "SSOEventManager");
        registerResource(oname, em);
        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                "/domain/sso-event-manager",
                                                                "/domain/sso-event-manager/class",
                                                                oname,
                                                                new String[0]));
        return em;
    }


    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    protected List fetchEventListeners(Configuration config) throws Exception {
        List listeners = super.fetchEventListeners(config);

        for (int i = 0; i < listeners.size(); i++) {
            SSOEventListener listener = (SSOEventListener) listeners.get(i);

            ObjectName oname = buildObjectName(listener, "SSOEventListener");
            registerResource(oname, listener);
            this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOGatewayConfigurationContext(),
                                                                    "/domain/sso-event-manager/listeners/listener[class='"+listener.getClass().getName()+"']",
                                                                    "/domain/sso-event-manager/listeners/listener[class='"+listener.getClass().getName()+"']/class",
                                                                    oname,
                                                                    new String[0]));

        }

        return listeners;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    public SSOAgent fetchSSOAgent() throws Exception {
        SSOAgent a = super.fetchSSOAgent();
        ObjectName oname = buildObjectName(a, "SSOAgent");
        registerResource(oname, a);

        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOAgentConfigurationContext(),
                                                                "/agent",
                                                                "/agent/class",
                                                                oname,
                                                                new String[] {"debug"}));

        this.registerSSOConfigurationEventListener(new SSOAgentConfigurationEventHandler(getSSOAgentConfigurationContext(),
                                                                "/agent/partner-apps",
                                                                "/agent/partner-apps/partner-app",
                                                                oname,
                                                                new String[] {"debug"}));

        SSOAgentInfo info = new SSOAgentInfo();
        oname = buildObjectName("type=SSOAgentInfo");
        registerResource(oname, info);

        return a;
    }

    /**
     * Registers a Model  MBean using the fetched comonent as managed resource.
     * Delegates component construction to parent class.
     */
    public GatewayServiceLocator fetchGatewayServiceLocator(Configuration config) throws Exception {
        GatewayServiceLocator gsl = super.fetchGatewayServiceLocator(config);
        ObjectName oname = buildObjectName(gsl, "GatewayServiceLocator");
        registerResource(oname, gsl);
        this.registerSSOConfigurationEventListener(new SSOConfigurationEventHandler(getSSOAgentConfigurationContext(),
                                                                "/agent/service-locator",
                                                                "/agent/service-locator/class",
                                                                oname,
                                                                new String[0]));
        return gsl;
    }

    // -----------------------------------------------------------------------------------------------


    /**
     * Adss a new listener to the chain.
     */
    protected void registerSSOConfigurationEventListener (SSOConfigurationEventListener listener) {
        if (!_eventListeners.contains(listener)) {
            _eventListeners.add(listener);
        }
    }

    // -----------------------------------------------------------------------------------------------

    /**
     * Util method to register a resource as a MBean.
     * The M
     *
     * @param resource the resource instance.
     */
    public void registerResource(Object resource) {
        registerResource(buildObjectName(resource), resource);
    }


    /**
     * Util to register any JOSSO resource as an MBean. This implementation is based on commons-modeler.
     * Subclasses may use a different JMX implementation.
     */
    public void registerResource(ObjectName oname, Object resource) {
        try {
            logger.info("Registering MBean : " + oname);
            _registry.registerComponent(resource, oname, null);

            MBeanServer server = getMBeanServer();
            server.addNotificationListener(oname, this, null, null);

        } catch (Exception e) {
            logger.error("Can't register resource as MBean : \n" + e.getMessage(), e);
        }
    }

    public ObjectName buildObjectName(Object o) {
        return buildObjectName(o, null);
    }

    /**
     * Builds a JMX Object name based on an object instance.
     */
    public ObjectName buildObjectName(Object o, String type) {

        // Get this MBean type
        if (type == null) {
            String className = o.getClass().getName();
            int period = className.lastIndexOf('.');
            if (period >= 0)
                className = className.substring(period + 1);
            type = className;
        }

        // Check fi this MBean has a "name" ...
        String name = null;
        try {
            Method m = o.getClass().getMethod("getName", new Class[0]);
            name = (String) m.invoke(o, new Object[0]);
        } catch (Exception e) {
            // Object does not have a name attribute, go on ...
        }

        String oname = "type=" + type + (name != null ? ",name=" + name : "");
        // Build the final ObjectName
        return buildObjectName(oname);
    }

    /**
     * This method builds an ObjectName instance, using the JOSSO JMX domain.
     */
    public ObjectName buildObjectName(String oname) {
        // Build the final ObjectName
        try {
            return new ObjectName(JOSSO_DOMAIN + ":" + oname);
        } catch (MalformedObjectNameException e) {
            logger.error("Can't build object name for [" + oname + "]\n:" + e.getMessage(), e);
            return null;
        }


    }

    /**
     * Finds the propper MBeanServer instance.
     */
    protected MBeanServer getMBeanServer() {
        return _registry.getMBeanServer();
    }


}
