/**
 * SSOIdentityManager.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2.1 Jul 21, 2005 (10:26:06 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.identity.service.ws.impl;

public interface SSOIdentityManager extends java.rmi.Remote {
    public void initialize() throws java.rmi.RemoteException;
    public org.josso.gateway.identity.service.ws.impl.SSOUser findUser(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException, org.josso.gateway.identity.service.ws.impl.NoSuchUserException;
    public org.josso.gateway.identity.service.ws.impl.SSOUser findUserInSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException, org.josso.gateway.identity.service.ws.impl.NoSuchUserException;
    public org.josso.gateway.identity.service.ws.impl.SSORole[] findRolesByUsername(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException;
    public void userExists(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.identity.service.ws.impl.SSOIdentityException, org.josso.gateway.identity.service.ws.impl.NoSuchUserException;
}
