/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.agent;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.util.config.ConfigurationContext;
import org.josso.util.config.SSOConfigurationEventHandler;

import java.util.EventObject;

/**
 * This ConfigurationHandler listens to SSOAgentMBean notifications to add or remove JOSSO partner application definitions
 * from JOSSO agent configuration file.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOAgentConfigurationEventHandler.java,v 1.2 2006/02/09 16:53:05 sgonzalez Exp $
 */

public class SSOAgentConfigurationEventHandler extends SSOConfigurationEventHandler {

    private static final Log logger = LogFactory.getLog(SSOAgentConfigurationEventHandler.class);


    /**
     * @param ctx                     the configuration context used by this handler.
     * @param elementsBaseLocation    a XPath expression used to determine where elements to be updated are found in the configuration file.
     * @param newElementsBaseLocation a XPath expression used to determine where new elements will be inserted as siblings in the configuration file.
     * @param source                  the event source this handler uses
     */
    public SSOAgentConfigurationEventHandler(ConfigurationContext ctx, String elementsBaseLocation, String newElementsBaseLocation, Object source, String[] ignoredAttrs) {
        super(ctx, elementsBaseLocation, newElementsBaseLocation, source, ignoredAttrs);
    }

    /**
     * @see SSOAgentMBean.SSOAgentMBeanNotification
     *
     * @return true only if the notification is instance of SSOAgentMBean.SSOAgentMBeanNotification
     */
    public boolean isEventEnabled(String eventType, EventObject event) {
        return event instanceof SSOAgentMBean.SSOAgentMBeanNotification;
    }

    /**
     * This method expects events of type SSOAgentMBean.SSOAgentMBeanNotification
     * It adds or removes a JOSSO partner application definition from the JOSSO agent configuration file.
     */
    public void handleEvent(String eventType, EventObject event) {

        // Get data needed to process this event.
        SSOAgentMBean.SSOAgentMBeanNotification notification = (SSOAgentMBean.SSOAgentMBeanNotification) event;

        // Build a XUpdate query string.
        if (eventType.equals(SSOAgentMBean.JOSSO_AGENT_EVENT_ADD_PARTNER_APP)) {
            SSOPartnerAppConfig cfg = (SSOPartnerAppConfig) notification.getUserData();
            addSSOPartnerAppConfig(cfg);

        } else if (eventType.equals(SSOAgentMBean.JOSSO_AGENT_EVENT_REMOVE_PARTNER_APP)) {
            String context = (String) notification.getUserData();
            removeSSOPartnerAppConfig(context);
        }

    }

    /**
     * This method will add a new partner app definition to josso configuration file.
     */
    protected void addSSOPartnerAppConfig(SSOPartnerAppConfig cfg) {
        String context = cfg.getContext();
        if (context == null || context.equals("")) {
            logger.error("addSSOPartnerAppConfig : received context is null or empty");
            return;
        }

        String xml = "            <context>" + cfg.getContext() + "</context>\n";

        if (cfg.getIgnoredWebRources() != null && cfg.getIgnoredWebRources().length > 0) {
            xml += "              <security-constraint>\n";
            for (int i = 0; i < cfg.getIgnoredWebRources().length; i++) {
                String s = cfg.getIgnoredWebRources()[i];
                xml += "                <ignore-web-resource-collection>"+s+"</ignore-web-resource-collection>\n";
            }
            xml += "              </security-constraint>";
        }

        String qry = this.buildXAppendElementXMLQueryString(getElementsBaseLocation(), "partner-app", xml);
        try {
            updateConfiguration(qry);
        }catch (Exception e) {
            logger.error("Can't add SSO partner application from to config ("+cfg.getContext()+")");
        }
    }

    /**
     * This method will remove a partner app definition from josso configuration file.
     */
    protected void removeSSOPartnerAppConfig(String context)  {
        if (context == null || context.equals("")) {
            logger.error("removeSSOPartnerAppConfig : received context is null or empty");
            return;
        }
        String qry = this.buildXDeleteElementQuery(getElementsBaseLocation(), "partner-app[context='" + context + "']");
        try {
            updateConfiguration(qry);
        } catch (Exception e) {
            logger.error("Can't remove SSO partner application from config ("+context+")");
        }
    }
}
