/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.identity.service;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.Lookup;
import org.josso.auth.Authenticator;
import org.josso.auth.AuthenticatorImpl;
import org.josso.gateway.identity.SSORole;
import org.josso.gateway.identity.SSOUser;
import org.josso.gateway.identity.exceptions.NoSuchUserException;
import org.josso.gateway.identity.exceptions.SSOIdentityException;
import org.josso.gateway.identity.service.store.IdentityStore;
import org.josso.gateway.identity.service.store.IdentityStoreKeyAdapter;
import org.josso.gateway.identity.service.store.SimpleUserKey;
import org.josso.gateway.identity.service.store.UserKey;
import org.josso.gateway.session.exceptions.NoSuchSessionException;
import org.josso.gateway.session.exceptions.SSOSessionException;
import org.josso.gateway.session.service.BaseSession;
import org.josso.gateway.session.service.SSOSessionManager;

/**
 * This is the default implementation of an SSOIdentityManager.
 * This implementation keeps track of user and session associations in memory.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOIdentityManagerImpl.java,v 1.26 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class SSOIdentityManagerImpl implements SSOIdentityManager {

    private static final Log logger = LogFactory.getLog(SSOIdentityManagerImpl.class);

    // Identity store used by the manager.
    private IdentityStore _store;
    private IdentityStoreKeyAdapter _keyAdapter;
    private SSOSessionManager _sessionManager;

    /**
     *
     */
    public SSOIdentityManagerImpl() {
    }

    /**
     * Finds a user based on its name.
     *
     * @param name the user login name, wich is unique for a domain.
     *
     *
     * @throws NoSuchUserException if the user does not exist for the domain.
     */
    public SSOUser findUser(String name)
            throws NoSuchUserException, SSOIdentityException {

        // Find user in store
        UserKey key = getIdentityStoreKeyAdapter().getKeyForUsername(name);
        BaseUser user = getIdentityStore().loadUser(key);
        if (user == null)
            throw new NoSuchUserException(key);

        // Done ... user found.
        return user;
    }

    /**
     * Finds the user associated to a sso session
     * 
     * @param sessionId the sso session identifier
     *
     * @throws SSOIdentityException if no user is associated to this session id.
     */
    public SSOUser findUserInSession(String sessionId)
        throws SSOIdentityException {

        BaseUser user = null;
        UserKey key = null;

        try {
            BaseSession s = (BaseSession) getSessionManager().getSession(sessionId);
            key = new SimpleUserKey(s.getUsername());
            user = getIdentityStore().loadUser(key);

            if (logger.isDebugEnabled())
                logger.debug("[findUserInSession("+sessionId+")] Found :  " + user);

            return user;

        } catch (NoSuchSessionException e) {
            throw new SSOIdentityException("Invalid session : " + sessionId);

        } catch (SSOSessionException e) {
            throw new SSOIdentityException(e.getMessage(), e);
        }

    }


    /**
     * Finds a collection of user's roles.
     * Elements in the collection are SSORole instances.
     *
     * @param username
     *
     * @throws SSOIdentityException
     */
    public SSORole[] findRolesByUsername(String username)
        throws SSOIdentityException {

        UserKey key = getIdentityStoreKeyAdapter().getKeyForUsername(username);
        return getIdentityStore().findRolesByUserKey(key);
    }

    /**
     * Checks if current user exists in this manager.
     *
     * @throws NoSuchUserException if the user does not exists.
     * @throws SSOIdentityException if an error occurs
     */
    public void userExists(String username) throws NoSuchUserException, SSOIdentityException {
        UserKey key = getIdentityStoreKeyAdapter().getKeyForUsername(username);
        if (!getIdentityStore().userExists(key))
            throw new NoSuchUserException(key);
    }


    // --------------------------------------------------------------------
    // Public utils
    // --------------------------------------------------------------------

    /**
     * Used to set the store for this manager.
     * @param s
     */
    public void setIdentityStore(IdentityStore s) {
        _store = s;
    }

    public void setIdentityStoreKeyAdapter(IdentityStoreKeyAdapter a) {
        _keyAdapter = a;
    }

    public void initialize() {

    }

    // --------------------------------------------------------------------
    // Protected utils
    // --------------------------------------------------------------------

    protected IdentityStore getIdentityStore() {
        return _store;
    }

    protected IdentityStoreKeyAdapter getIdentityStoreKeyAdapter() {
        return _keyAdapter;
    }

    protected Authenticator getAuthenticator() {
        return new AuthenticatorImpl();
    }

    protected SSOSessionManager getSessionManager() {

        if (_sessionManager == null) {

            try {
                _sessionManager = Lookup.getInstance().lookupSecurityDomain().getSessionManager();
            } catch (Exception e) {
                logger.error("Can't find Session Manager : \n" + e.getMessage() != null ? e.getMessage() : e.toString(), e);
            }
        }

        return _sessionManager;
    }


}
