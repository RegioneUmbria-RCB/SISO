/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.util.config;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.SSOConfigurationEventListener;

import javax.management.AttributeChangeNotification;
import java.util.EventObject;

/**
 * This ConfigurationHandler receives SSOEvents and uses them to update JOSSO configuration files.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SSOConfigurationEventHandler.java,v 1.2 2006/02/09 16:53:06 sgonzalez Exp $
 */
public class SSOConfigurationEventHandler extends XUpdateConfigurationHandler implements SSOConfigurationEventListener {

    private static final Log logger = LogFactory.getLog(SSOConfigurationEventHandler.class);

    private Object source;

    private String[] ignoredAttrs;

    /**
     * @param ctx the ConfigurationContext used by this handler.
     * @param elementsBaseLocation a XPath expression used to determine where elements to be updated are found in the configuration file.
     * @param newElementsBaseLocation a XPath expression used to determine where new elements will be inserted as siblings in the configuration file.
     * @param source the event source this handler uses
     */
    public SSOConfigurationEventHandler(ConfigurationContext ctx, String elementsBaseLocation, String newElementsBaseLocation, Object source, String[] ignoredAttrs) {
        super(ctx, elementsBaseLocation, newElementsBaseLocation);
        this.source = source;
        this.ignoredAttrs = ignoredAttrs;
    }


    /**
     * Handles an BaseSSOEvent and updates JOSSO config if necessary.
     * The event object must be instance of javax.management.AttributeChangeNotification
     *
     * @param eventType the event type (this may be a JMX event type)
     * @param event the event object. Only AttributeChangeNotification events are supported by this handler.
     */
    public void handleEvent(String eventType, EventObject event) {

        // An attribute has change in the SSOAgent ... update config file.
        if (event instanceof AttributeChangeNotification ) {
            AttributeChangeNotification notification = (AttributeChangeNotification) event;
            String attrName = notification.getAttributeName();

            if (ignore(attrName))
                return;

            // This should cover longs, ints and of course, strings.
            String newValue = notification.getNewValue().toString();
            String oldValue = (notification.getOldValue() != null ? notification.getOldValue().toString() : null);

            this.saveElement(attrName, oldValue, newValue);
        }

    }

    /**
     * Only handles events of type : "jmx.attribute.change" for the supported resource.
     */
    public boolean isEventEnabled(String eventType, EventObject event) {
        // This will only handle SSOAgent related events :
        return source.equals(event.getSource());
    }

    /**
     * Util to determine if an attribute must be ignored.
     * Subclasses may add different behavior.
     *
     */
    protected boolean ignore(String attrName) {
        for (int i = 0; i < ignoredAttrs.length; i++) {
            String ignoredAttr = ignoredAttrs[i];
            if (ignoredAttr.equals(attrName))
                return true;
        }
        return false;
    }


}
