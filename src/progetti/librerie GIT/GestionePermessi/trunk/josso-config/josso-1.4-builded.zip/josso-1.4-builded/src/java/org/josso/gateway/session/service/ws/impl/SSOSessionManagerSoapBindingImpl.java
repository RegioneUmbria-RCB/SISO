/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * SSOSessionManagerSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.2alpha ago 27, 2004 (08:42:06 GMT-03:00) WSDL2Java emitter.
 */

package org.josso.gateway.session.service.ws.impl;

import org.josso.Lookup;
import org.josso.SecurityDomain;

import java.rmi.RemoteException;

public class SSOSessionManagerSoapBindingImpl implements org.josso.gateway.session.service.ws.impl.SSOSessionManager{
    public org.josso.gateway.session.service.ws.impl.SSOSession getSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException {
        return null;
    }

    public java.lang.String initiateSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    /**
     * Gets all SSO sessions.
     */
    public Object[] getSessions() throws RemoteException, SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this implementation");
    }
    
    public Object[] getUserSessions(String in0) throws RemoteException, NoSuchSessionException, SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    public void accessSession(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException {
        try {
            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            domain.getSessionManager().accessSession(in0);
        } catch (org.josso.gateway.session.exceptions.NoSuchSessionException e) {
          throw new org.josso.gateway.session.service.ws.impl.NoSuchSessionException();
        } catch (Exception e) {
          throw new org.josso.gateway.session.service.ws.impl.SSOSessionException();
        }

    }

    public int getSessionCount() throws RemoteException, SSOSessionException {
        try {
            SecurityDomain domain = Lookup.getInstance().lookupSecurityDomain();
            return domain.getSessionManager().getSessionCount();
        } catch (org.josso.gateway.session.exceptions.NoSuchSessionException e) {
          throw new org.josso.gateway.session.service.ws.impl.NoSuchSessionException();
        } catch (Exception e) {
          throw new org.josso.gateway.session.service.ws.impl.SSOSessionException();
        }
    }

    public void invalidateAll() throws RemoteException, SSOSessionException {
        //To change body of implemented methods use File | Settings | File Templates.
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    public void invalidate(java.lang.String in0) throws java.rmi.RemoteException, org.josso.gateway.session.service.ws.impl.NoSuchSessionException, org.josso.gateway.session.service.ws.impl.SSOSessionException {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    public void checkValidSessions() throws java.rmi.RemoteException {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

    public void initialize() throws RemoteException {
        throw new UnsupportedOperationException("Not supported by this type of manager");
    }

}
