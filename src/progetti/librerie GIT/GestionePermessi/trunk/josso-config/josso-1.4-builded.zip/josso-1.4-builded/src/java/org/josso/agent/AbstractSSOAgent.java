/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.agent;

import org.josso.gateway.GatewayServiceLocator;
import org.josso.gateway.identity.service.SSOIdentityManager;
import org.josso.gateway.session.exceptions.NoSuchSessionException;
import org.josso.gateway.session.service.SSOSessionManager;

import java.security.Principal;
import java.util.HashMap;

/**
 * Represents a partial implementation of an Single Sign-on Agent.
 * An Agent stands in between the Gateway and the Security Domain were partner application reside.
 * It provides transparent security context to partner applications, providing user and role information
 * by invoking the gateway through JAAS.
 *
 * @author <a href="mailto:gbrigand@josso.org">Gianluca Brigandi</a>
 * @version CVS $Id: AbstractSSOAgent.java,v 1.22 2006/02/09 16:53:05 sgonzalez Exp $
 */

public abstract class AbstractSSOAgent implements SSOAgent {

    public static final long DEFAULT_SESSION_ACCESS_MIN_INTERVAL = 1000;

    // ----------------------------------------------------- Instance Variables
    /**
     * The cache of SingleSignOnEntry instances for authenticated Principals,
     * keyed by the cookie value that is used to select them.
     */
    protected HashMap cache = new HashMap();

    /**
     * The cache of single sign on identifiers, keyed by the Session that is
     * associated with them.
     */
    protected HashMap reverse = new HashMap();
    protected boolean started = false;
    protected int debug = 0;
    protected SSOAgentConfiguration _cfg;

    private GatewayServiceLocator _gsl;
    private SSOSessionManager _sm;
    private SSOIdentityManager _im;

    private String _gatewayLoginUrl;
    private String _gatewayLogoutUrl;

    private String _gatewayLoginErrorUrl;

    private String _singlePointOfAccess;

    private long _sessionAccessMinInterval = DEFAULT_SESSION_ACCESS_MIN_INTERVAL;

    // Some statistical information :
    private long _requestCount;
    private long _l1CacheHits;
    private long _l2CacheHits;


    // ----------------------------------------------------- Properties

    /**
     * Configures the Gateway Service Locator to be used by the SSOAgent.
     *
     * @param gsl
     */
    public void setGatewayServiceLocator(GatewayServiceLocator gsl) {
        _gsl = gsl;
    }

    /**
     * Obtains the Gateway Service Locator used by the SSOAgent to build
     * the concrete clients needed to query the Gateway services.
     *
     * This getter is need by the JAASLoginModule to know which Gateway Service Locator to use.
     *
     * @return the configured gateway service locator
     */
    public GatewayServiceLocator getGatewayServiceLocator() {
        return _gsl;
    }

    public SSOSessionManager getSSOSessionManager() {
        return _sm;
    }

    public SSOIdentityManager getSSOIdentityManager() {
        return _im;
    }

    /**
     * Sets the Login Form Url of the Gateway.
     */
    public void setGatewayLoginUrl(String gatewayLoginUrl) {
        _gatewayLoginUrl = gatewayLoginUrl;
    }

    /**
     * Returns the Login Form Url of the Gateway.
     *
     * @return the gateway login url
     */
    public String getGatewayLoginUrl() {
        return _gatewayLoginUrl;
    }

    /**
     * Returns the Error Login Url of the Gateway.
     *
     * @return the gateway login url
     */
    public String getGatewayLoginErrorUrl() {
        return _gatewayLoginErrorUrl;
    }

    /**
     * Sets the Error Login Url of the Gateway.
     */
    public void setGatewayLoginErrorUrl(String gatewayLoginErrorUrl) {
        _gatewayLoginErrorUrl = gatewayLoginErrorUrl;
    }

    /**
     * Sets the Logout Form Url of the Gateway.
     */
    public void setGatewayLogoutUrl(String gatewayLogoutUrl) {
        _gatewayLogoutUrl = gatewayLogoutUrl;
    }

    /**
     * Returns the Logout Form Url of the Gateway.
     *
     * @return the gateway login url
     */
    public String getGatewayLogoutUrl() {
        return _gatewayLogoutUrl;
    }

    /**
     * Used by the configuraiton, to set the session access min interval.
     */
    public void setSessionAccessMinInterval(String v) {
        setSessionAccessMinInterval(Long.parseLong(v));
    }

    /**
     * Gets the session access min interval.
     */
    public long getSessionAccessMinInterval() {
        return _sessionAccessMinInterval;
    }

    /**
     * Sets the session access min interval.
     */
    public void setSessionAccessMinInterval(long sessionAccessMinInterval) {
        _sessionAccessMinInterval = sessionAccessMinInterval;
    }

    /**
     * Single Point of Access to the SSO infrastructure. Useful when working in N-Tier mode behind a reverse proxy or
     * load balancer
     */
    public String getSinglePointOfAccess() {
        return _singlePointOfAccess;
    }

    /**
     * Single Point of Access to the SSO infrastructure. Useful when working in N-Tier mode behind a reverse proxy or
     * load balancer
     * @param singlePointOfAccess
     */
    public void setSinglePointOfAccess(String singlePointOfAccess) {
        _singlePointOfAccess = singlePointOfAccess;
    }

    /**
     * Returns true if the received context should be processed by this agent.  It means that
     * the context belongs to a partner application.
     * @param contextPath the web application context to be checked.
     * @return true if this context belongs to a josso partner app.
     */
    public boolean isPartnerApp(String contextPath) {
        return getPartnerAppConfig(contextPath) != null;
    }

    /**
     * Returns the partner application configuration definition associtated with the given context.
     * If no partner application is defined for the context, returns null.
     */
    public SSOPartnerAppConfig getPartnerAppConfig(String contextPath) {
        SSOPartnerAppConfig[] papps = _cfg.getSSOPartnerApps();
        for (int i = 0; i < papps.length; i++) {
            SSOPartnerAppConfig ssoPartnerAppConfig = papps[i];

            if (contextPath.equals(ssoPartnerAppConfig.getContext()))
                return ssoPartnerAppConfig;
        }
        return null;

    }

    /**
     * Starts the Agent.
     */
    public void start() {
        try {
            _sm = _gsl.getSSOSessionManager();
            _im = _gsl.getSSOIdentityManager();

            if (debug > 0)
                log("Agent Started");
        } catch (Exception e) {
            log("Can't create session/identity managers : \n" + e.getMessage(), e);
        }

    }

    /**
     * Authenticated a user session previously authenticated by the gateway.
     *
     * @param request the JOSSO Agent request
     * @return the logged user identity.
     */
    public SingleSignOnEntry processRequest(SSOAgentRequest request) {

        // Count this request.
        _requestCount ++;

        String jossoSessionId = request.getSessionId();
        LocalSession localSession = request.getLocalSession();

        // Look up the cached Principal associated with this cookie value
        if (debug > 0)
            log("Checking for cached principal for " + jossoSessionId);

        SingleSignOnEntry entry = lookup(jossoSessionId);
        if (entry != null) {

            if (debug > 0)
                log(" Found cached principal '" +
                    entry.principal.getName() + "' with auth type '" +
                    entry.authType + "'");

            // Count the cache hit.
            _l1CacheHits ++;

            entry = accessSession(entry, jossoSessionId);
            return entry;
        }

        // Make the agent receive local session events.
        localSession.addSessionListener(this);

        // Associated local session to the SSO Session
        associateLocalSession(jossoSessionId, localSession);

        // Invoke the JAAS Gateway Login Module to obtain user information
        Principal ssoUserPrincipal = authenticate(request);

        if (ssoUserPrincipal != null)
        {
            if (debug > 0)
                log("Principal checked for SSO Session '" + jossoSessionId + "' : " + ssoUserPrincipal);

            register(jossoSessionId, ssoUserPrincipal, "JOSSO");
            entry = lookup(jossoSessionId);
            entry = accessSession(entry, jossoSessionId);
            return entry;

        }

        if (debug > 0)
                log("There is no associated principal for SSO Session '" + jossoSessionId + "'");

        return null;

    }

    /**
     * Access sso session related with given entry.  If sso session is no longer valid,
     * deregisters the session and return null.
     *
     * @param entry
     * @return null if the sso session is no longer valid.
     */
    protected SingleSignOnEntry accessSession(SingleSignOnEntry entry, String jossoSessionId)  {

        // Just in case
        if (entry == null)
            return entry;

        // Do not access server more than once in a second ...
        long now = System.currentTimeMillis();
        if ( (now - entry.lastAccessTime) < getSessionAccessMinInterval()) {
            _l2CacheHits ++;
            return entry;
        }

        try {
            // send a keep-alive event for the SSO session

            if (debug > 0)
                log("Notifying keep-alive event for session '" + jossoSessionId + "'");

            _sm.accessSession(jossoSessionId);
            entry.lastAccessTime = now;
            return entry;

        } catch (NoSuchSessionException e) {
            if (debug > 0)
                log("SSO Session is no longer valid");

            deregister(entry.ssoId);
            return null;

        } catch (Exception e) {
            log(e.getMessage() != null ? e.getMessage() : e.toString(), e);
            deregister(entry.ssoId);
            return null;
        }

    }


    /**
     * Template method used by the agent to obtain a principal from a SSO Agent request.
     *
     * @param request
     * @return the authenticated principal.
     */
    abstract protected Principal authenticate(SSOAgentRequest request);



    /**
     * Log a message on the Logger associated with our Container (if any).
     *
     * @param message Message to be logged
     */
    abstract protected void log (String message) ;

    /**
     * Log a message on the Logger associated with our Container (if any).
     *
     * @param message   Message to be logged
     * @param throwable Associated exception
     */
    abstract protected void log(String message, Throwable throwable) ;

    /**
     * Stop the Agent.
     */
    public void stop() {
        if (debug > 0)
            log("Agent Stopped");

    }

    // ------------------------------------------------ LocalSessionListener Methods

    /**
     * Acknowledge the occurrence of the specified event.
     *
     * @param event SessionEvent that has occurred
     */
    public void localSessionEvent(LocalSessionEvent event) {

        // We only care about session destroyed events
        if (!LocalSession.LOCAL_SESSION_DESTROYED_EVENT.equals(event.getType()))
            return;

        // Look up the single session id associated with this session (if any)
        LocalSession session = event.getLocalSession();

        if (debug > 0)
            log("Local session destroyed on " + session);

        // notify gateway that the session was destroyed.
        localSessionDestroyedEvent(session);

    }

    public void setConfiguration(SSOAgentConfiguration cfg) {
        _cfg = cfg;
    }

    public SSOAgentConfiguration getConfiguration() {
        return _cfg;
    }

    /**
     * Disassociates a Local Session from the Single Sign-on session since the Local Session
     * was destroyed.
     *
     * @param session
     */
    protected void localSessionDestroyedEvent(LocalSession session) {
        String ssoId = null;
        synchronized (reverse) {
            ssoId = (String) reverse.get(session);
        }
        if (ssoId == null)
            return;

        // Deregister this single sso session id, invalidating associated sessions
        deregister(ssoId);
    }


    /**
     * Associate the specified single sign on identifier with the
     * specified Session.
     *
     * @param ssoId Single sign on identifier
     * @param localSession Local Session to be associated to the SSO Session.
     */
    protected void associateLocalSession(String ssoId, LocalSession localSession) {

        SingleSignOnEntry sso = lookup(ssoId);
        if (sso != null)
            sso.addSession(localSession);
        synchronized (reverse) {
            reverse.put(localSession, ssoId);
        }

    }

    /**
     * Deregister the specified single sign on identifier, and invalidate
     * any associated sessions.
     *
     * @param ssoId Single sign on identifier to deregister
     */
    protected void deregister(String ssoId) {

        // Look up and remove the corresponding SingleSignOnEntry
        SingleSignOnEntry sso = null;
        synchronized (cache) {
            sso = (SingleSignOnEntry) cache.remove(ssoId);
        }
        if (sso == null)
            return;

        // Expire any associated sessions
        LocalSession localSessions[] = sso.findSessions();
        for (int i = 0; i < localSessions.length; i++) {

            // Remove from reverse cache first to avoid recursion
            synchronized (reverse) {
                reverse.remove(localSessions[i]);
            }
            // Invalidate this session
            localSessions[i].exipre();

        }

    }


    /**
     * Register the specified Principal as being associated with the specified
     * value for the single sign on identifier.
     *
     * @param ssoId Single sign on identifier to register
     * @param principal Associated user principal that is identified
     * @param authType Authentication type used to authenticate this
     *  user principal
     */
    protected void register(String ssoId, Principal principal, String authType ) {

        synchronized (cache) {
            cache.put(ssoId, new SingleSignOnEntry(principal, ssoId, authType));
        }

    }

    /**
     * Look up and return the cached SingleSignOn entry associated with this
     * sso id value, if there is one; otherwise return <code>null</code>.
     *
     * @param ssoId Single sign on identifier to look up
     */
    protected SingleSignOnEntry lookup(String ssoId) {
        synchronized (cache) {
            return ((SingleSignOnEntry) cache.get(ssoId));
        }
    }

    public int getDebug() {
        return debug;
    }

    public void setDebug(int debug) {
        this.debug = debug;
    }

    public long getRequestCount() {
        return _requestCount;
    }

    public long getL1CacheHits() {
        return _l1CacheHits;
    }

    public long getL2CacheHits() {
        return _l2CacheHits;
    }

}

