/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.signon;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.struts.action.*;
import org.josso.Lookup;
import org.josso.auth.Credential;
import org.josso.auth.exceptions.AuthenticationFailureException;
import org.josso.gateway.SSOContext;
import org.josso.gateway.SSOGateway;
import org.josso.gateway.SSOWebConfiguration;
import org.josso.gateway.session.SSOSession;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Base login action extended by concrete actions associated to specific authentication schemes.
 * This actions controls the auth. process and invokes subclasses methods (template method).
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: LoginAction.java,v 1.22 2006/02/09 16:53:06 sgonzalez Exp $
 */

public abstract class LoginAction extends SignonBaseAction {

    public static final String JOSSO_CMD_LOGIN = "login";

    private static final Log logger = LogFactory.getLog(LoginAction.class);

    /**
     * Executes the propper login method based on sso_command request parameter.
     */
    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response) throws Exception {

        // Get current SSO Command ...
        String cmd = getSSOCmd(request);
        if (cmd == null) {
            return askForLogin(mapping, form, request, response);
        }

        return login(mapping, form, request, response);

    }

    /**
     * Ask the user for login information.
     */
    protected ActionForward askForLogin(ActionMapping mapping,
                                        ActionForm form,
                                        HttpServletRequest request,
                                        HttpServletResponse response) {

        storeSsoParameters(request);
        // Ask user for login information.
        return mapping.findForward("login-page");
    }


    /**
     * Logins the user in the SSO infrastructure
     *
     */
    protected ActionForward login(ActionMapping mapping,
                                  ActionForm form,
                                  HttpServletRequest request,
                                  HttpServletResponse response) {

        Credential[] c = null;
        try {

            SSOContext ctx = getNewSSOContext(request);
            c = getCredentials(request);

            try {

                storeSsoParameters(request);
                SSOWebConfiguration cfg = Lookup.getInstance().lookupSSOWebConfiguration();

                // 1. Login :
                SSOGateway g = getSSOGateway();
                SSOSession session = g.login(c, ctx.getScheme(), ctx); // Actual login with received credentials.
                String username = session.getUsername();

                Cookie ssoCookie = newJossoCookie(session.getId());
                response.addCookie(ssoCookie);

                // 2 - Add messesges to display to user..
                ActionErrors msg = new ActionErrors();
                msg.add(ActionErrors.GLOBAL_ERROR, new ActionError("sso.login.success", username));
                msg.add(ActionErrors.GLOBAL_ERROR, new ActionError("sso.info.session", session.getId()));

                // 3- Redirect the user to the propper page, if any
                HttpSession httpSession = request.getSession();
                String back_to = (String) httpSession.getAttribute(KEY_JOSSO_BACK_TO);

                if (back_to == null) {
                    back_to = cfg.getLoginBackToURL();
                }

                if (back_to != null) {
                    msg.add(ActionErrors.GLOBAL_ERROR, new ActionError("sso.login.redirect",back_to));

                    // Remove this attributes once used
                    httpSession.removeAttribute(KEY_JOSSO_BACK_TO);
                    httpSession.removeAttribute(KEY_JOSSO_ON_ERROR);

                    // We're going back to the partner app.
                    if (logger.isDebugEnabled())
                        logger.debug("[login()], ok->redirecting to : " + back_to);
                    response.sendRedirect(response.encodeRedirectURL(back_to));
                    return null; // No forward is needed.
                }

                if (logger.isDebugEnabled())
                    logger.debug("[login()], ok.");

                saveErrors(request, msg);

                // 4 - Return to controller.
                return mapping.findForward("login-result");

            } catch (AuthenticationFailureException e) {

                if (logger.isDebugEnabled())
                    logger.debug(e.getMessage(), e);

                // Invalid login attempt, redirect to on_error, if found.
                String on_error = (String) request.getSession(true).getAttribute(KEY_JOSSO_ON_ERROR);
                if (on_error != null) {
                    response.sendRedirect(response.encodeRedirectURL(on_error));
                    if (logger.isDebugEnabled())
                        logger.debug("[login()], invalid->redirecting to : " + on_error);
                    return null; // No forward is needed.
                }

                ActionErrors errors = new ActionErrors();
                errors.add(ActionErrors.GLOBAL_ERROR, new ActionError("sso.login.failed"));

                saveErrors(request, errors);
                return mapping.findForward("login-page");
            }

        } catch (Exception e) {

            // Fatal error ...
            logger.error(e.getMessage(), e);
            ActionErrors errors = new ActionErrors();
            errors.add(ActionErrors.GLOBAL_ERROR, new ActionError("sso.error", e.getMessage() != null ? e.getMessage() : e.toString()));
            saveErrors(request, errors);
            return mapping.findForward("error");
        }



    }

    /**
     * This method stores sso parameters in session.
     * @param request
     */
    protected void storeSsoParameters(HttpServletRequest request) {
        // Get a session
        HttpSession s = request.getSession(true);

        // Store back_to url, if present.
        String back_to=request.getParameter(PARAM_JOSSO_BACK_TO);
        if (back_to != null && !"".equals(back_to)) {
            s.setAttribute(KEY_JOSSO_BACK_TO, back_to);
            if (logger.isDebugEnabled())
                logger.debug("[askForLogin()] Storing back-to url in session : " + back_to);
        }

        // Store on_error url if present.
        String on_error=request.getParameter(PARAM_JOSSO_ON_ERROR);
        if (on_error != null && !"".equals(on_error)) {
            s.setAttribute(KEY_JOSSO_ON_ERROR, on_error);
            if (logger.isDebugEnabled())
                logger.debug("[askForLogin()] Storing on-error url in session : " + on_error);
        }

    }

    protected String getBackTo(HttpServletRequest request) {
        HttpSession s = request.getSession();
        return (String) s.getAttribute(KEY_JOSSO_BACK_TO);
    }

    protected String getOnError(HttpServletRequest request) {
        HttpSession s = request.getSession();
        return (String) s.getAttribute(KEY_JOSSO_ON_ERROR);
    }


}
