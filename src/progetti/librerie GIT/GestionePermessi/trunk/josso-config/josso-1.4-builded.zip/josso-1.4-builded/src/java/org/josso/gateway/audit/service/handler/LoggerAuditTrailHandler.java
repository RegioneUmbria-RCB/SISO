/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.audit.service.handler;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.josso.gateway.audit.SSOAuditTrail;

import java.util.Enumeration;
import java.util.Properties;

/**
 * This audit trail handler sends all received trails to configured logger.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: LoggerAuditTrailHandler.java,v 1.5 2006/02/15 15:43:24 sgonzalez Exp $
 */
public class LoggerAuditTrailHandler extends BaseAuditTrailHandler {

    private Log logger = LogFactory.getLog(LoggerAuditTrailHandler.class);

    // The logger category :
    private String category;

    public int handle(SSOAuditTrail trail) {

        StringBuffer line = new StringBuffer();


        // Append TIME : CATEGORY - SEVERITY -
        line.append(trail.getTime()).append(" - ").append(trail.getCategory()).append(" - ").append(trail.getSeverity());

        // Append SUBJECT - ACTION=OUTCOME
        line.append(" - ").append(trail.getSubject() == null ? "" : trail.getSubject()).append(" - ").append(trail.getAction()).append("=").append(trail.getOutcome());


        // Append properties PROPERTIES:p1=v1,p2=v2
        Properties properties = trail.getProperties();
        Enumeration names = properties.propertyNames();

        if (names.hasMoreElements()) {
            line.append(" - ");
        }

        while (names.hasMoreElements()) {
            String key = (String) names.nextElement();
            String value = properties.getProperty(key);
            line.append(key).append("=").append(value);

            if (names.hasMoreElements())
                line.append(",");
        }

        // Log error information !?
        // Append error informatino if any : ERROR:<message><classname>
        if (trail.getError() != null) {
            line.append(" - ERROR:").append(trail.getError().getMessage()).append(":").append(trail.getError().getClass().getName());
            // Append error cause informatino if any : ERROR_CAUSE:<message><classname>
            if (trail.getError().getCause() != null) {
                line.append(" ERROR_CAUSE:").append(trail.getError().getCause().getMessage()).append(":").append(trail.getError().getClass().getName());
            }
        }

        // Logging the propper line :
        logger.info(line);

        return CONTINUE_PROCESS;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
        logger = LogFactory.getLog(category);
    }
}
