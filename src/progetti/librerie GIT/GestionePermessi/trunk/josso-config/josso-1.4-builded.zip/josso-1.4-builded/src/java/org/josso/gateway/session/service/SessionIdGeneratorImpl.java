/*
 *   Copyright (c) 2004-2006, Novascope S.A. and the JOSSO team
 *    All rights reserved.
 *    Redistribution and use in source and binary forms, with or
 *    without modification, are permitted provided that the following
 *    conditions are met:
 *
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in
 *      the documentation and/or other materials provided with the
 *      distribution.
 *
 *    * Neither the name of the JOSSO team nor the names of its
 *      contributors may be used to endorse or promote products derived
 *      from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 *    CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 *    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 *    MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS
 *    BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 *    TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 *    ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *    OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *    POSSIBILITY OF SUCH DAMAGE.
 */
package org.josso.gateway.session.service;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

/**
 * This is an implementation of a session id generatod based on Jakarta Tomcat 5.0
 * session id generation.
 * This implementation is thread safe.
 *
 * @author <a href="mailto:sgonzalez@josso.org">Sebastian Gonzalez Oyuela</a>
 * @version $Id: SessionIdGeneratorImpl.java,v 1.6 2006/02/09 16:53:06 sgonzalez Exp $
 */

public class SessionIdGeneratorImpl implements SessionIdGenerator {

    private static final Log logger = LogFactory.getLog(SessionIdGeneratorImpl.class);

    /**
     * The default message digest algorithm to use if we cannot use
     * the requested one.
     */
    protected static final String DEFAULT_ALGORITHM = "MD5";

    /**
     * The message digest algorithm to be used when generating session
     * identifiers.  This must be an algorithm supported by the
     * <code>java.security.MessageDigest</code> class on your platform.
     */
    private String _algorithm = DEFAULT_ALGORITHM;

    private int _sessionIdLength = 16;
    private String _entropy;
    private Random _random;

    /**
     * The Java class name of the random number generator class to be used
     * when generating session identifiers.
     */
    protected String _randomClass = "java.security.SecureRandom";

    /**
     * Generate and return a new session identifier.
     */
    public synchronized String generateSessionId() {

        byte random[] = new byte[16];

        // Render the result as a String of hexadecimal digits
        StringBuffer result = new StringBuffer();
        int resultLenBytes = 0;
        while (resultLenBytes < _sessionIdLength) {
            getRandomBytes(random);
            random = getDigest().digest(random);
            for (int j = 0;
                 j < random.length && resultLenBytes < _sessionIdLength;
                 j++) {
                byte b1 = (byte) ((random[j] & 0xf0) >> 4);
                byte b2 = (byte) (random[j] & 0x0f);
                if (b1 < 10)
                    result.append((char) ('0' + b1));
                else
                    result.append((char) ('A' + (b1 - 10)));
                if (b2 < 10)
                    result.append((char) ('0' + b2));
                else
                    result.append((char) ('A' + (b2 - 10)));
                resultLenBytes++;
            }
        }
        return (result.toString());

    }

    /**
     * Return the random number generator instance we should use for
     * generating session identifiers.  If there is no such generator
     * currently defined, construct and seed a new one.
     */
    public synchronized Random getRandom() {

        if (_random == null) {
            synchronized (this) {
                if (_random == null) {
                    // Calculate the new random number generator seed
                    long seed = System.currentTimeMillis();
                    long t1 = seed;
                    char entropy[] = getEntropy().toCharArray();
                    for (int i = 0; i < entropy.length; i++) {
                        long update = ((byte) entropy[i]) << ((i % 8) * 8);
                        seed ^= update;
                    }
                    try {
                        // Construct and seed a new random number generator
                        Class clazz = Class.forName(_randomClass);
                        _random = (Random) clazz.newInstance();
                        _random.setSeed(seed);
                    } catch (Exception e) {
                        // Can't instantiate random class, fall back to the simple case
                        logger.error("Can't use random class : " + _randomClass + ", fall back to the simple case.", e);
                        _random = new java.util.Random();
                        _random.setSeed(seed);
                    }
                    // Log a debug msg if this is taking too long ...
                    long t2 = System.currentTimeMillis();
                    if ((t2 - t1) > 100)
                        logger.debug("Delay getting Random with class : " + _randomClass + " [getRandom()] " + (t2 - t1) + " ms.");
                }
            }
        }

        return (_random);

    }

    /**
     * Return the MessageDigest object to be used for calculating
     * session identifiers.  If none has been created yet, initialize
     * one the first time this method is called.
     */
    public synchronized MessageDigest getDigest() {

        MessageDigest digest = null;
        if (_algorithm != null) {

            try {
                digest = MessageDigest.getInstance(_algorithm);
                logger.debug("Using hash algorithm/encoding : " + _algorithm);
            } catch (NoSuchAlgorithmException e) {
                logger.error("Algorithm not supported : " + _algorithm, e);
                try {
                    digest = MessageDigest.getInstance(DEFAULT_ALGORITHM);
                } catch (NoSuchAlgorithmException f) {
                    logger.error("Algorithm not supported : " + DEFAULT_ALGORITHM, e);
                    digest = null;
                }
            }
        }

        return digest;

    }


    /**
     * Generate a byte array containing a session identifier
     */
    protected void getRandomBytes(byte[] bytes) {
        // TODO : Performance may be improved by using O.S. Specific devices like /dev/urandom (see tomcat 5.0)
        Random random = getRandom();
        random.nextBytes(bytes);
    }

    /**
     * Return the entropy increaser value, or compute a semi-useful value
     * if this String has not yet been set.
     */
    public String getEntropy() {

        // Calculate a semi-useful value if this has not been set
        if (_entropy == null)
            setEntropy(this.toString());

        return (_entropy);

    }


    /**
     * Set the entropy increaser value.
     *
     * @param entropy The new entropy increaser value
     */
    public void setEntropy(String entropy) {
        // String oldEntropy = entropy;
        _entropy = entropy;

    }


    /**
     * Return the digest algorithm for the id generator.
     *
     * @return String the algorithm name (i.e. MD5).
     */
    public String getAlgorithm() {
        return _algorithm;
    }

    /**
     * Set the message digest algorithm for the id generator.
     *
     * @param algorithm The new message digest algorithm
     */
    public void setAlgorithm(String algorithm) {
        _algorithm = algorithm;
    }

    /**
     * Gets the session id length (in bytes) for Sessions created by this
     * Generator
     */
    public int getSessionIdLength() {
        return _sessionIdLength;
    }

    /**
     * Sets the session id length (in bytes) for Sessions created by this
     * Generator
     *
     * @param idLength The session id length
     */
    public void setSessionIdLength(int idLength) {
        _sessionIdLength = idLength;
    }


    /**
     * Gets the random number generator class name.
     */
    public String getRandomClass() {
        return _randomClass;
    }

    /**
     * Sets the random number generator class name.
     */
    public void setRandomClass(String randomClass) {
        _randomClass = randomClass;
        _random = null;
    }


}
